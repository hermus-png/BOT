/*
 * کامند !help
 * راهنمای کامل دو زبانه از تمام کامندها
 */

const { sendToOwner } = require('../utils/msg')

const HELP_FA = [
  '━━━━━━ 📖 راهنمای pvp_HSbot ━━━━━━',
  '',
  '⚙️  عمومی:',
  '  !lang 1|2     → تغییر زبان (1=فارسی 2=English)',
  '  !help         → این راهنما',
  '  !stats        → آمار بات (پینگ، TPS، HP، …)',
  '  !render <n>   → تنظیم رندر دیستنس (۲ تا ۳۲)',
  '',
  '🎯 تیپی و ریسپان:',
  '  !tpa          → بات به pvp_HS تیپی میده',
  '  !home         → پیدا کردن تخت + ست کردن ریسپان',
  '  (تیپی pvp_HS خودکار قبول میشه، بقیه رد میشن)',
  '',
  '🎒 اینونتوری:',
  '  !drop         → دراپ همه (به جز آرمور/الیترا/گاپل/۱توتم)',
  '                  + AutoTotem خودکار فعال',
  '',
  '🎮 مود‌ها:',
  '  !mode 0       → هیچ مودی (فقط کامندهای عمومی)',
  '  !mode 1       → مود شالکر فارم (دستگاه فایربال)',
  '  !mode 2       → مود کیت دادن',
  '',
  '🏭 مود ۱ (Shulker Farm):',
  '  !scan         → اسکن دستی دستگاه',
  '  !start        → شروع سیکل خودکار',
  '  !stop         → توقف مود',
  '',
  '🎁 مود ۲ (Kit):',
  '  ?kit pvp      → برداشتن کیت + تیپی + دراپ',
  '  !confirm      → تایید /kill بعد از دراپ',
  '  !stop         → توقف مود',
  '',
  '🔐 امنیت: فقط pvp_HS کنترل داره. UUID چک میشه.',
  '━━━━━━━━━━━━━━━━━━━━━━━━━━━'
]

const HELP_EN = [
  '━━━━━━ 📖 pvp_HSbot Guide ━━━━━━',
  '',
  '⚙️  General:',
  '  !lang 1|2     → change language',
  '  !help         → this help',
  '  !stats        → bot stats (ping, TPS, HP, …)',
  '  !render <n>   → set render distance (2–32)',
  '',
  '🎯 TPA & Home:',
  '  !tpa          → bot sends tpa to pvp_HS',
  '  !home         → find bed + set respawn',
  '  (pvp_HS tpa auto-accepted, others denied)',
  '',
  '🎒 Inventory:',
  '  !drop         → drop all (except armor/elytra/gapple/1 totem)',
  '                  + AutoTotem enabled',
  '',
  '🎮 Modes:',
  '  !mode 0       → no mode (only general commands)',
  '  !mode 1       → Shulker Farm mode',
  '  !mode 2       → Kit mode',
  '',
  '🏭 Mode 1 (Shulker Farm):',
  '  !scan         → manual device scan',
  '  !start        → start auto cycle',
  '  !stop         → stop mode',
  '',
  '🎁 Mode 2 (Kit):',
  '  ?kit pvp      → get kit + tpa + drop',
  '  !confirm      → confirm /kill after drop',
  '  !stop         → stop mode',
  '',
  '🔐 Security: Only pvp_HS controls. UUID verified.',
  '━━━━━━━━━━━━━━━━━━━━━━━━━━━'
]

function handleHelp(bot, lang) {
  const lines = lang === 'fa' ? HELP_FA : HELP_EN
  for (const l of lines) sendToOwner(bot, l)
}

module.exports = { handleHelp }
