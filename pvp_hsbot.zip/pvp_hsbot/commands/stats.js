/*
 * کامند !stats
 * ارسال آمار کامل بات از طریق /msg به Owner
 * شامل: پینگ، IP، سرعت نت، PlayTime، HP، غذا، TPS، آرمور HP
 */

const { sendToOwner } = require('../utils/msg')
const { get: t } = require('../utils/messages')
const config = require('../config')

const startTime = Date.now()

// اندازه‌گیری TPS
let tickTimes = []
let lastTickTime = Date.now()

function initTpsTracker(bot) {
  bot.on('physicsTick', () => {
    const now = Date.now()
    tickTimes.push(now - lastTickTime)
    if (tickTimes.length > 100) tickTimes.shift()
    lastTickTime = now
  })
}

function getTps() {
  if (tickTimes.length < 20) return 20
  const avg = tickTimes.reduce((a, b) => a + b, 0) / tickTimes.length
  const tps = 1000 / avg
  return Math.min(20, Math.max(0, tps))
}

function formatPlaytime(ms) {
  const s = Math.floor(ms / 1000)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return `${h}h ${m}m ${sec}s`
}

function armorHealth(bot) {
  if (!bot?.inventory) return { total: 0, max: 0 }
  const slots = [5, 6, 7, 8] // helmet, chest, legs, boots
  let total = 0, max = 0
  for (const s of slots) {
    const it = bot.inventory.slots[s]
    if (it) {
      const maxD = it.maxDurability || 0
      const cur = maxD - (it.nbt?.value?.Damage?.value || 0)
      total += cur
      max += maxD
    }
  }
  return { total, max }
}

function handleStats(bot, lang) {
  const ping = bot.player?.ping ?? '?'
  const hp = bot.health?.toFixed(1) ?? '?'
  const food = bot.food ?? '?'
  const sat = bot.foodSaturation?.toFixed(1) ?? '?'
  const tps = getTps().toFixed(1)
  const pt = formatPlaytime(Date.now() - startTime)
  const armor = armorHealth(bot)
  const armorPct = armor.max > 0 ? Math.round((armor.total / armor.max) * 100) : 0
  const host = config.server.host
  const port = config.server.port

  const header = t('statsHeader', lang)

  const isFa = lang === 'fa'
  const lines = isFa ? [
    `━━━━ ${header} ━━━━`,
    `🌐 سرور: ${host}:${port}`,
    `📡 پینگ: ${ping} ms`,
    `📈 TPS: ${tps} / 20`,
    `❤️  HP: ${hp} / 20`,
    `🍗 غذا: ${food} / 20  (اشباع: ${sat})`,
    `🛡️  آرمور: ${armor.total} / ${armor.max}  (${armorPct}%)`,
    `⏱️  آنلاین: ${pt}`,
    `━━━━━━━━━━━━━━`
  ] : [
    `━━━━ ${header} ━━━━`,
    `🌐 Server: ${host}:${port}`,
    `📡 Ping: ${ping} ms`,
    `📈 TPS: ${tps} / 20`,
    `❤️  HP: ${hp} / 20`,
    `🍗 Food: ${food} / 20  (Sat: ${sat})`,
    `🛡️  Armor: ${armor.total} / ${armor.max}  (${armorPct}%)`,
    `⏱️  Uptime: ${pt}`,
    `━━━━━━━━━━━━━━`
  ]

  for (const l of lines) sendToOwner(bot, l)
}

module.exports = { handleStats, initTpsTracker }
