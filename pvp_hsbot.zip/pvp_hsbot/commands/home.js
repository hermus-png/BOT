/*
 * کامند !home
 * - اسکن 16 بلاکی برای تخت
 * - راست‌کلیک روی نزدیک‌ترین تخت
 * - چک کردن پیام تایید respawn
 */

const { sendToOwner } = require('../utils/msg')
const { get: t } = require('../utils/messages')
const { humanRightClick, sleep } = require('../utils/human')
const { log } = require('../utils/logger')

let awaitingConfirm = false
let confirmTimer = null

// لیست بلاک‌های تخت (همه رنگ‌ها)
const BED_NAMES = [
  'white_bed', 'orange_bed', 'magenta_bed', 'light_blue_bed',
  'yellow_bed', 'lime_bed', 'pink_bed', 'gray_bed',
  'light_gray_bed', 'cyan_bed', 'purple_bed', 'blue_bed',
  'brown_bed', 'green_bed', 'red_bed', 'black_bed'
]

async function handleHome(bot, lang) {
  if (!bot?.entity) return

  const mcData = require('minecraft-data')(bot.version)
  const bedIds = []
  for (const name of BED_NAMES) {
    const b = mcData.blocksByName[name]
    if (b) bedIds.push(b.id)
  }

  const beds = bot.findBlocks({
    matching: bedIds,
    maxDistance: 16,
    count: 20
  })

  if (!beds || beds.length === 0) {
    sendToOwner(bot, t('homeBedNotFound', lang))
    return
  }

  sendToOwner(bot, t('homeBedFound', lang, beds.length))

  // نزدیک‌ترین رو انتخاب کن
  const botPos = bot.entity.position
  beds.sort((a, b) => a.distanceTo(botPos) - b.distanceTo(botPos))
  const nearest = bot.blockAt(beds[0])
  if (!nearest) return

  // منتظر پیام respawn
  awaitingConfirm = true
  clearTimeout(confirmTimer)
  confirmTimer = setTimeout(() => {
    if (awaitingConfirm) {
      awaitingConfirm = false
      sendToOwner(bot, t('homeSetUnknown', lang))
    }
  }, 5000)

  await humanRightClick(bot, nearest)
  log('HOME', `Clicked bed at ${nearest.position}`)
}

/*
 * چک کردن پیام سرور برای تایید set respawn
 */
function checkRespawnSet(bot, message, lang) {
  if (!awaitingConfirm) return
  const text = message.toLowerCase()
  if (
    text.includes('respawn point set') ||
    text.includes('respawn point') ||
    text.includes('bed set') ||
    text.includes('now your spawn')
  ) {
    awaitingConfirm = false
    clearTimeout(confirmTimer)
    sendToOwner(bot, t('homeSet', lang))
  }
}

module.exports = { handleHome, checkRespawnSet }
