/*
 * کامندهای TPA
 * - !tpa  → بات به owner تیپی میده
 * - قبول خودکار تیپی که owner فرستاد
 */

const { sendCommand, sendToOwner } = require('../utils/msg')
const { get: t } = require('../utils/messages')
const config = require('../config')
const { log } = require('../utils/logger')

let lastTpaTime = 0

function canTpa() {
  const now = Date.now()
  const cd = config.cooldowns.tpaSeconds * 1000
  if (now - lastTpaTime < cd) {
    return Math.ceil((cd - (now - lastTpaTime)) / 1000)
  }
  return 0
}

// وقتی owner توی چت !tpa میزنه → بات براش تیپی میفرسته
function handleTpaFromOwner(bot, lang) {
  const remaining = canTpa()
  if (remaining > 0) {
    sendToOwner(bot, t('cooldown', lang, remaining))
    return
  }
  sendCommand(bot, `/tpa ${config.owner.name}`)
  lastTpaTime = Date.now()
  sendToOwner(bot, t('tpaSent', lang))
}

/*
 * تشخیص پیام‌های سرور برای درخواست‌های TPA
 * الگوهای رایج 6b6t:
 *   "pvp_HS has requested to teleport to you"
 *   "pvp_HS wants to teleport to you"
 *   "Type /tpy pvp_HS to accept"
 */
function checkTpaRequest(bot, message, lang) {
  const text = message.toLowerCase()
  const owner = config.owner.name.toLowerCase()

  // آیا پیام حاوی درخواست تیپی هست؟
  const isTpaMsg =
    text.includes('teleport') && text.includes('request') ||
    text.includes('/tpy ') ||
    text.includes('wants to teleport')

  if (!isTpaMsg) return false

  // آیا از owner هست؟
  if (text.includes(owner)) {
    log('TPA', `Owner tpa detected → accepting`)
    setTimeout(() => {
      sendCommand(bot, `/tpy ${config.owner.name}`)
      sendToOwner(bot, t('tpaReceived', lang))
    }, 800 + Math.random() * 700)
    return true
  }

  // از فرد غیرمجاز - رد کن
  // اسم فرستنده رو استخراج کن
  const match = message.match(/(\w+)\s+(has|wants)/i)
  if (match) {
    const sender = match[1]
    if (sender.toLowerCase() !== owner) {
      log('TPA', `Non-owner tpa from ${sender} → denying`)
      setTimeout(() => {
        sendCommand(bot, `/tpn ${sender}`)
        sendToOwner(bot, t('tpaDenied', lang))
      }, 600)
      return true
    }
  }

  return false
}

module.exports = { handleTpaFromOwner, checkTpaRequest }
