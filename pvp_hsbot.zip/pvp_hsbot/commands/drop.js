/*
 * کامند !drop
 * دراپ تمام آیتم‌ها به جز:
 *   - آرمور (helmet, chestplate, leggings, boots)
 *   - الیترا (elytra)
 *   - گلدن اپل (golden_apple, enchanted_golden_apple)
 *   - ۱ توتم (نگه داری میشه، بقیه دراپ)
 *
 * + AutoTotem: توتم رو به دست چپ (offhand) منتقل میکنه
 */

const { sendToOwner } = require('../utils/msg')
const { get: t } = require('../utils/messages')
const { sleep, randInt } = require('../utils/human')
const { log } = require('../utils/logger')

// آیتم‌هایی که نگه داشته میشن
const KEEP_ITEMS = new Set([
  'elytra',
  'golden_apple',
  'enchanted_golden_apple'
])

// اسلات‌های armor توی window (نگه داشته میشن)
const ARMOR_KEYWORDS = ['helmet', 'chestplate', 'leggings', 'boots']

function isArmor(itemName) {
  return ARMOR_KEYWORDS.some(k => itemName.includes(k))
}

function isKeeper(itemName) {
  if (KEEP_ITEMS.has(itemName)) return true
  if (isArmor(itemName)) return true
  return false
}

async function autoTotem(bot, lang) {
  if (!bot?.inventory) return

  const offhand = bot.inventory.slots[45] // offhand slot
  if (offhand && offhand.name === 'totem_of_undying') {
    return // قبلا توتم دست چپ هست
  }

  const totem = bot.inventory.items().find(i => i.name === 'totem_of_undying')
  if (!totem) return

  try {
    await bot.equip(totem, 'off-hand')
    if (lang) sendToOwner(bot, t('autoTotem', lang))
    log('AUTOTOTEM', 'Totem moved to offhand')
  } catch (e) {
    log('AUTOTOTEM', `Failed: ${e.message}`)
  }
}

async function handleDrop(bot, lang) {
  if (!bot?.inventory) return

  // اول AutoTotem
  await autoTotem(bot, lang)
  await sleep(300)

  const items = bot.inventory.items()
  let dropped = 0
  let totemKept = false

  for (const item of items) {
    // نگه داشتن آرمور / الیترا / گلدن‌اپل
    if (isKeeper(item.name)) continue

    // نگه داشتن ۱ توتم (بقیه دراپ)
    if (item.name === 'totem_of_undying') {
      if (!totemKept) {
        totemKept = true
        continue
      }
    }

    try {
      await bot.tossStack(item)
      dropped++
      await sleep(randInt(80, 180))
    } catch (e) {
      log('DROP', `Failed to drop ${item.name}: ${e.message}`)
    }
  }

  sendToOwner(bot, t('dropDone', lang, dropped))
}

module.exports = { handleDrop, autoTotem }
