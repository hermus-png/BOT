/*
 * =============================================================
 *  MODE 2 - Kit Giver
 * =============================================================
 *  فرآیند وقتی owner توی چت "?kit pvp" میزنه:
 *    1) بات میره سراغ چست‌های نزدیک، توش دنبال شالکر میگرده
 *    2) شالکر PvP kit (شامل: کریستال، آرمور نداریتی، گاپل، سورد) → برمیداره
 *    3) شالکر توتم (پر از توتم) → برمیداره
 *    4) به pvp_HS تیپی میده
 *    5) بعد از رسیدن، اسم owner رو نگاه میکنه
 *    6) کیت رو دراپ میکنه
 *    7) توی /msg میگه "کیت آماده" و منتظر !confirm میمونه
 *    8) بعد از !confirm → /kill میزنه → میره ریسپان
 * =============================================================
 */

const { sendToOwner, sendCommand } = require('../utils/msg')
const { get: t } = require('../utils/messages')
const { sleep, randInt, humanRightClick, lookAt } = require('../utils/human')
const { log } = require('../utils/logger')
const config = require('../config')
const storage = require('../utils/storage')

let state = {
  running: false,
  awaitingConfirm: false,
  step: 'idle'
}

// آیتم‌های کلیدی PvP kit
const PVP_KIT_ITEMS = [
  'end_crystal',
  'netherite_helmet', 'netherite_chestplate', 'netherite_leggings', 'netherite_boots',
  'netherite_sword',
  'golden_apple', 'enchanted_golden_apple',
  'obsidian', 'ender_pearl'
]

function isPvpKitShulker(items) {
  // آیتم‌های داخل شالکر (از NBT)
  if (!items || items.length === 0) return false
  const names = items.map(i => (i.name || '').toLowerCase())
  const hasArmor = names.some(n => n.includes('netherite_helmet') || n.includes('netherite_chestplate'))
  const hasSword = names.some(n => n.includes('sword'))
  const hasCrystal = names.some(n => n.includes('end_crystal'))
  return (hasArmor && hasSword) || (hasCrystal && hasArmor)
}

function isTotemShulker(items) {
  if (!items || items.length === 0) return false
  const totemCount = items.filter(i => i.name === 'totem_of_undying').length
  return totemCount >= 5
}

// خوندن آیتم‌های داخل یک شالکر از NBT (بدون باز کردنش)
function readShulkerContents(shulkerItem) {
  try {
    const tag = shulkerItem.nbt?.value?.BlockEntityTag?.value
    if (!tag) return []
    const items = tag.Items?.value?.value || []
    return items.map(it => ({
      name: (it.id?.value || '').replace('minecraft:', ''),
      count: it.Count?.value || 0
    }))
  } catch {
    return []
  }
}

/*
 * پیدا کردن و باز کردن چست‌های نزدیک تا شالکر مناسب پیدا کنیم
 */
async function findAndTakeShulker(bot, checkFn, lang, label) {
  const mcData = require('minecraft-data')(bot.version)
  const chestIds = [
    mcData.blocksByName.chest?.id,
    mcData.blocksByName.trapped_chest?.id
  ].filter(Boolean)

  const chestPositions = bot.findBlocks({
    matching: chestIds,
    maxDistance: 16,
    count: 20
  })

  for (const cp of chestPositions) {
    const chestBlock = bot.blockAt(cp)
    if (!chestBlock) continue

    try {
      const win = await bot.openContainer(chestBlock)
      await sleep(randInt(400, 700))

      // بین آیتم‌های چست دنبال شالکر بگرد
      const shulkers = win.containerItems().filter(i => i.name.includes('shulker_box'))

      for (const sh of shulkers) {
        const contents = readShulkerContents(sh)
        if (checkFn(contents)) {
          // این شالکر رو بردار
          try {
            await win.withdraw(sh.type, sh.metadata, 1)
            await sleep(randInt(300, 500))
            await win.close()
            log('KIT', `Took ${label} shulker`)
            return true
          } catch (e) {
            log('KIT', `Withdraw failed: ${e.message}`)
          }
        }
      }

      await win.close()
      await sleep(randInt(200, 400))
    } catch (e) {
      log('KIT', `Cannot open chest: ${e.message}`)
    }
  }

  return false
}

/*
 * دراپ کیت (فقط آیتم‌های kit، نه آرمور فعلی بات)
 */
async function dropKit(bot) {
  const items = bot.inventory.items()
  let dropped = 0

  for (const it of items) {
    // شالکرهای kit رو دراپ کن + آیتم‌های kit
    if (it.name.includes('shulker_box')) {
      try {
        await bot.tossStack(it)
        dropped++
        await sleep(randInt(150, 300))
      } catch {}
    }
  }

  return dropped
}

/*
 * شروع فرآیند کیت
 */
async function startKit(bot, lang) {
  if (state.running) {
    sendToOwner(bot, lang === 'fa' ? '⚠️ فرآیند کیت در جریانه' : '⚠️ Kit process running')
    return
  }

  state.running = true
  state.step = 'looking'

  sendToOwner(bot, t('kitLooking', lang))

  // 1) شالکر PvP kit
  const gotPvp = await findAndTakeShulker(bot, isPvpKitShulker, lang, 'PvP')
  if (!gotPvp) {
    sendToOwner(bot, lang === 'fa'
      ? '❌ شالکر PvP kit توی چست‌ها پیدا نشد'
      : '❌ PvP kit shulker not found in chests')
    state.running = false
    return
  }
  sendToOwner(bot, t('kitTaken', lang))

  await sleep(randInt(600, 1000))

  // 2) شالکر توتم
  const gotTotem = await findAndTakeShulker(bot, isTotemShulker, lang, 'Totem')
  if (!gotTotem) {
    sendToOwner(bot, lang === 'fa'
      ? '⚠️ شالکر توتم پیدا نشد - بدونش ادامه میدم'
      : '⚠️ Totem shulker not found - continuing without it')
  } else {
    sendToOwner(bot, t('kitTotemTaken', lang))
  }

  // 3) تیپی به owner
  await sleep(randInt(800, 1200))
  state.step = 'teleporting'
  sendCommand(bot, `/tpa ${config.owner.name}`)
  sendToOwner(bot, lang === 'fa'
    ? '📤 تیپی زدم، لطفاً با /tpy قبول کن'
    : '📤 TPA sent, please /tpy to accept')

  // منتظر رسیدن به owner (چند ثانیه)
  await sleep(6000)

  // 4) پیدا کردن owner در نزدیکی برای تایید
  const ownerPlayer = bot.players[config.owner.name]
  if (ownerPlayer && ownerPlayer.entity) {
    await lookAt(bot, ownerPlayer.entity.position.offset(0, 1.5, 0))
    await sleep(randInt(400, 700))
    log('KIT', 'Owner spotted')
  }

  // 5) دراپ کیت
  state.step = 'dropping'
  const n = await dropKit(bot)
  log('KIT', `Dropped ${n} kit items`)

  // 6) پیام "کیت آماده" + منتظر !confirm
  state.step = 'awaiting_confirm'
  state.awaitingConfirm = true
  sendToOwner(bot, t('kitReady', lang))
  sendToOwner(bot, t('awaitingConfirm', lang))

  // آمار
  const totals = storage.load().totalKitsGiven || 0
  storage.update({ totalKitsGiven: totals + 1 })
}

/*
 * confirm از owner
 */
async function confirmKill(bot, lang) {
  if (!state.awaitingConfirm) {
    sendToOwner(bot, lang === 'fa'
      ? 'ℹ️ منتظر تایید نبودم'
      : 'ℹ️ Not waiting for confirm')
    return
  }

  state.awaitingConfirm = false
  state.step = 'killing'
  sendToOwner(bot, t('killed', lang))
  await sleep(randInt(300, 600))
  sendCommand(bot, '/kill')

  await sleep(3000)
  state.running = false
  state.step = 'idle'
}

function stop() {
  state.running = false
  state.awaitingConfirm = false
  state.step = 'idle'
}

function isRunning() {
  return state.running
}

function isAwaitingConfirm() {
  return state.awaitingConfirm
}

module.exports = { startKit, confirmKill, stop, isRunning, isAwaitingConfirm }
