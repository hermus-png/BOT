/*
 * =============================================================
 *  MODE 1 - Shulker Farm (دستگاه فایربال)
 * =============================================================
 *  ساختار دستگاه:
 *    - دکمه ۱ (Loader): با فشار → دیسپنسر ۱ ماین‌کارت چست میزاره
 *      → بات روش کلیک میکنه (باز میشه) → همه شالکرهای اینونتوری داخلش میره
 *    - دکمه ۲ (Fireball): با فشار → دیسپنسر ۲ فایربال میزنه به ماین‌کارت
 *      → ماین‌کارت با شالکرها منفجر میشه
 *
 *  الگوریتم:
 *    1) اسکن 16 بلاکی → پیدا کردن دکمه‌ها، دیسپنسرها، چست‌ها، ماین‌کارت‌ها
 *    2) تشخیص هوشمند: دکمه‌ای که نزدیک دیسپنسر با ماین‌کارت هست = دکمه Loader
 *       دکمه‌ای که نزدیک دیسپنسر با فایربال هست = دکمه Fireball
 *    3) سیکل:
 *       - اگه ماین‌کارت چست توی اینونتوری بود → دراپش کن
 *       - دکمه Loader بزن → صبر → روی ماین‌کارت چست کلیک راست → شالکرها بریز
 *       - دکمه Fireball بزن → صبر → دوباره
 * =============================================================
 */

const { sendToOwner } = require('../utils/msg')
const { get: t } = require('../utils/messages')
const { sleep, randInt, humanLeftClick, humanRightClick, lookAt } = require('../utils/human')
const { log } = require('../utils/logger')
const config = require('../config')
const storage = require('../utils/storage')

let state = {
  running: false,
  device: null,        // { loaderButton, fireballButton, loaderDispenser, fireballDispenser, chests }
  cycles: 0,
  stopRequested: false
}

/*
 * اسکن اطراف بات
 */
async function scan(bot) {
  const mcData = require('minecraft-data')(bot.version)

  const buttonIds = Object.values(mcData.blocksByName)
    .filter(b => b.name.includes('button'))
    .map(b => b.id)

  const dispenserId = mcData.blocksByName.dispenser?.id
  const chestIds = [
    mcData.blocksByName.chest?.id,
    mcData.blocksByName.trapped_chest?.id
  ].filter(Boolean)

  const R = config.shulkerFarm.scanRadius

  const buttons = bot.findBlocks({ matching: buttonIds, maxDistance: R, count: 20 })
  const dispensers = bot.findBlocks({ matching: [dispenserId], maxDistance: R, count: 20 })
  const chests = bot.findBlocks({ matching: chestIds, maxDistance: R, count: 20 })

  // ماین‌کارت‌های موجود
  const carts = Object.values(bot.entities).filter(e => {
    if (!e || !e.position) return false
    const d = e.position.distanceTo(bot.entity.position)
    if (d > R) return false
    const n = (e.name || e.displayName || '').toLowerCase()
    return n.includes('chest_minecart') || n.includes('minecart with chest') || n === 'chest_minecart'
  })

  // تشخیص هوشمند: هر دیسپنسر رو چک میکنیم که فایربال داره یا نه
  // (بدون باز کردن با اسکن NBT ممکن نیست، پس از موقعیت ماین‌کارت استفاده میکنیم)
  //   → دیسپنسر نزدیک به ماین‌کارت = Fireball dispenser
  //   → دیسپنسر دورتر = Loader dispenser

  let loaderDisp = null
  let fireballDisp = null

  if (carts.length > 0 && dispensers.length >= 2) {
    const sorted = [...dispensers].sort((a, b) => {
      const da = Math.min(...carts.map(c => c.position.distanceTo(a)))
      const db = Math.min(...carts.map(c => c.position.distanceTo(b)))
      return da - db
    })
    fireballDisp = sorted[0]
    loaderDisp = sorted[sorted.length - 1]
  } else if (dispensers.length >= 2) {
    // بدون ماین‌کارت مرجع، اولی رو Loader و دومی رو Fireball میگیریم
    loaderDisp = dispensers[0]
    fireballDisp = dispensers[1]
  } else if (dispensers.length === 1) {
    loaderDisp = dispensers[0]
  }

  // دکمه Loader = دکمه‌ای که نزدیک‌ترین به دیسپنسر Loader هست
  // دکمه Fireball = دکمه‌ای که نزدیک‌ترین به دیسپنسر Fireball هست
  let loaderBtn = null
  let fireballBtn = null

  if (buttons.length >= 2 && loaderDisp && fireballDisp) {
    const sortedBtns = [...buttons].sort((a, b) => {
      return a.distanceTo(loaderDisp) - b.distanceTo(loaderDisp)
    })
    loaderBtn = sortedBtns[0]
    // دومی نزدیک به fireballDisp
    const remaining = sortedBtns.slice(1)
    remaining.sort((a, b) => a.distanceTo(fireballDisp) - b.distanceTo(fireballDisp))
    fireballBtn = remaining[0] || sortedBtns[1]
  } else if (buttons.length >= 2) {
    loaderBtn = buttons[0]
    fireballBtn = buttons[1]
  }

  state.device = {
    loaderButton: loaderBtn,
    fireballButton: fireballBtn,
    loaderDispenser: loaderDisp,
    fireballDispenser: fireballDisp,
    chests
  }

  return {
    buttons: buttons.length,
    dispensers: dispensers.length,
    chests: chests.length,
    carts: carts.length
  }
}

async function handleScan(bot, lang) {
  const r = await scan(bot)
  sendToOwner(bot, t('shulkerScanDone', lang, r.buttons, r.dispensers, r.chests, r.carts))

  if (!state.device.loaderButton || !state.device.fireballButton) {
    sendToOwner(bot, t('shulkerNoDevice', lang))
    return false
  }
  return true
}

// دراپ ماین‌کارت چست از اینونتوری
async function dropMinecartChest(bot) {
  const items = bot.inventory.items().filter(i =>
    i.name === 'chest_minecart' || i.name === 'minecart_with_chest'
  )
  for (const it of items) {
    try {
      await bot.tossStack(it)
      await sleep(randInt(150, 300))
    } catch {}
  }
}

// پیدا کردن ماین‌کارت چست فعال جلوی دیسپنسر
function findActiveCart(bot) {
  const R = 5
  const disp = state.device.fireballDispenser || state.device.loaderDispenser
  if (!disp) return null

  const carts = Object.values(bot.entities).filter(e => {
    if (!e || !e.position) return false
    const n = (e.name || e.displayName || '').toLowerCase()
    if (!n.includes('chest_minecart') && !n.includes('minecart')) return false
    return e.position.distanceTo(disp) <= R
  })

  return carts[0] || null
}

/*
 * یک سیکل کامل
 */
async function runOneCycle(bot, lang) {
  const d = state.device
  if (!d || !d.loaderButton || !d.fireballButton) return false

  // 1) اگه ماین‌کارت چست توی اینونتوری هست، دراپش کن
  await dropMinecartChest(bot)
  await sleep(randInt(400, 700))

  // 2) کلیک روی دکمه Loader
  const btn1 = bot.blockAt(d.loaderButton)
  if (!btn1) return false
  await humanRightClick(bot, btn1)
  log('SHULKER', 'Loader button pressed')

  // صبر تا دیسپنسر ماین‌کارت رو بذاره
  await sleep(randInt(1200, 1800))

  // 3) پیدا کردن ماین‌کارت چست فعال و کلیک روش
  const cart = findActiveCart(bot)
  if (cart) {
    await lookAt(bot, cart)
    await sleep(randInt(300, 600))
    try {
      await bot.activateEntity(cart)
      await sleep(randInt(600, 900))
    } catch (e) {
      log('SHULKER', `Cannot open cart: ${e.message}`)
    }

    // انتقال همه شالکرها به ماین‌کارت
    if (bot.currentWindow) {
      const shulkers = bot.inventory.items().filter(i => i.name.includes('shulker_box'))
      for (const sh of shulkers) {
        try {
          await bot.moveSlotItem(sh.slot, bot.currentWindow.firstEmptyContainerSlot())
          await sleep(randInt(80, 160))
        } catch {}
      }
      try { bot.closeWindow(bot.currentWindow) } catch {}
      await sleep(randInt(300, 500))
    }
  }

  // 4) کلیک روی دکمه Fireball
  const btn2 = bot.blockAt(d.fireballButton)
  if (btn2) {
    await humanRightClick(bot, btn2)
    log('SHULKER', 'Fireball button pressed')
    await sleep(randInt(1500, 2000))
  }

  state.cycles++
  const totals = storage.load().totalShulkersProcessed || 0
  storage.update({ totalShulkersProcessed: totals + 1 })
  sendToOwner(bot, t('shulkerCycleDone', lang, state.cycles))

  return true
}

async function start(bot, lang) {
  if (state.running) {
    sendToOwner(bot, '⚠️ Shulker Farm already running')
    return
  }

  // اگه اسکن نشده، اول اسکن کن
  if (!state.device || !state.device.loaderButton) {
    const ok = await handleScan(bot, lang)
    if (!ok) return
  }

  state.running = true
  state.stopRequested = false
  state.cycles = 0

  sendToOwner(bot, lang === 'fa' ? '▶️ Shulker Farm شروع شد' : '▶️ Shulker Farm started')

  // حلقه اصلی
  while (state.running && !state.stopRequested) {
    try {
      await runOneCycle(bot, lang)
    } catch (e) {
      log('SHULKER', `Cycle error: ${e.message}`)
      sendToOwner(bot, `⚠️ Cycle error: ${e.message}`)
    }

    await sleep(config.timing.shulkerCycleWaitMs)

    if (config.shulkerFarm.maxCycles > 0 && state.cycles >= config.shulkerFarm.maxCycles) {
      break
    }

    // چک اینونتوری خالی از شالکر
    const hasShulker = bot.inventory.items().some(i => i.name.includes('shulker_box'))
    if (!hasShulker) {
      sendToOwner(bot, lang === 'fa'
        ? '📭 شالکری توی اینونتوری نمونده - توقف'
        : '📭 No more shulkers in inventory - stopping')
      break
    }
  }

  state.running = false
  sendToOwner(bot, t('modeStop', lang))
}

function stop() {
  state.stopRequested = true
  state.running = false
}

function isRunning() {
  return state.running
}

module.exports = { start, stop, isRunning, handleScan }
