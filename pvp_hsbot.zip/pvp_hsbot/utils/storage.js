/*
 * Storage utility - ذخیره و بارگذاری تنظیمات از فایل config.json
 * ذخیره: owner UUID, render distance, mode فعلی, زبان
 */

const fs = require('fs')
const path = require('path')

const DATA_FILE = path.join(__dirname, '..', 'data', 'config.json')

const DEFAULT_DATA = {
  ownerUUID: null,          // اولین بار که owner دیده شد ذخیره میشه
  language: null,           // 'fa' یا 'en' - اول بار پرسیده میشه
  currentMode: 0,           // 0 = هیچ‌کدوم, 1 = Shulker Farm, 2 = Kit
  renderDistance: 12,
  lastRespawnSet: null,
  totalShulkersProcessed: 0,
  totalKitsGiven: 0
}

function ensureDataDir() {
  const dir = path.dirname(DATA_FILE)
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
}

function load() {
  ensureDataDir()
  try {
    if (!fs.existsSync(DATA_FILE)) {
      save(DEFAULT_DATA)
      return { ...DEFAULT_DATA }
    }
    const raw = fs.readFileSync(DATA_FILE, 'utf8')
    const data = JSON.parse(raw)
    return { ...DEFAULT_DATA, ...data }
  } catch {
    return { ...DEFAULT_DATA }
  }
}

function save(data) {
  ensureDataDir()
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2))
  } catch (e) {
    console.error('[STORAGE] Save failed:', e.message)
  }
}

function update(patch) {
  const cur = load()
  const next = { ...cur, ...patch }
  save(next)
  return next
}

module.exports = { load, save, update }
