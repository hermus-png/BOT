/*
 * Logger utility - لاگ گرفتن با تایم و رنگ
 */

const fs = require('fs')
const path = require('path')

const LOG_FILE = path.join(__dirname, '..', 'data', 'bot.log')

function now() {
  return new Date().toLocaleTimeString('en-GB')
}

function writeFile(line) {
  try {
    fs.appendFileSync(LOG_FILE, line + '\n')
  } catch {}
}

function log(type, msg) {
  const line = `[${now()}] [${type}] ${msg}`
  console.log(line)
  writeFile(line)
}

function section(title) {
  const bar = '='.repeat(64)
  console.log('\n' + bar)
  console.log(' ' + title)
  console.log(bar)
  writeFile('\n' + bar + '\n ' + title + '\n' + bar)
}

module.exports = { log, section, now }
