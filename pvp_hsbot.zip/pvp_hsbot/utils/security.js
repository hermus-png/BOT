/*
 * Security utility - سیستم امنیت و تشخیص Owner
 * فقط pvp_HS میتونه کنترل کنه
 */

const config = require('../config')
const storage = require('./storage')
const { log } = require('./logger')

/*
 * بررسی اینکه فرستنده پیام واقعا Owner هست
 * - چک اسم دقیق (case-sensitive)
 * - اگه UUID داشتیم چک UUID
 * - اگه UUID نداشتیم اولین بار ذخیره میکنیم
 */
function isOwner(bot, username) {
  if (!username) return false

  // چک اسم دقیق
  if (username !== config.owner.name) return false

  // گرفتن UUID از لیست پلیرها
  const player = bot.players[username]
  if (!player) {
    log('SECURITY', `Owner name matched but player object missing`)
    return false
  }

  const uuid = player.uuid
  if (!uuid) return false

  const data = storage.load()

  // اولین بار - ذخیره UUID
  if (!data.ownerUUID) {
    storage.update({ ownerUUID: uuid })
    log('SECURITY', `Owner UUID stored: ${uuid}`)
    return true
  }

  // چک تطابق UUID
  if (data.ownerUUID !== uuid) {
    log('SECURITY', `BLOCKED: Name matched but UUID mismatch! Fake owner attempt from ${uuid}`)
    return false
  }

  return true
}

/*
 * ری‌ست کردن UUID (اگه لازم شد)
 */
function resetOwner() {
  storage.update({ ownerUUID: null })
  log('SECURITY', 'Owner UUID reset')
}

module.exports = { isOwner, resetOwner }
