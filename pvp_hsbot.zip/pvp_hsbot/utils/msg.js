/*
 * MSG utility - ارسال پیام فقط از طریق /msg به Owner
 * هیچ‌وقت توی چت پابلیک چیزی نمیفرسته
 *
 * + مدیریت لیمیت چت / کول‌داون
 */

const config = require('../config')
const { log } = require('./logger')

let lastChatTime = 0
const chatQueue = []
let processing = false

async function processQueue(bot) {
  if (processing) return
  processing = true

  while (chatQueue.length > 0) {
    const now = Date.now()
    const diff = now - lastChatTime

    if (diff < config.cooldowns.chatCooldownMs) {
      await new Promise(r => setTimeout(r, config.cooldowns.chatCooldownMs - diff))
    }

    const msg = chatQueue.shift()
    try {
      bot.chat(msg)
      lastChatTime = Date.now()
    } catch (e) {
      log('MSG', `Chat send failed: ${e.message}`)
    }
  }

  processing = false
}

/*
 * ارسال پیام خصوصی به Owner
 */
function sendToOwner(bot, text) {
  if (!bot || !text) return
  const line = `/msg ${config.owner.name} ${text}`
  chatQueue.push(line)
  log('MSG->OWNER', text)
  processQueue(bot)
}

/*
 * ارسال کامند سرور (نه پیام)
 */
function sendCommand(bot, cmd) {
  if (!bot || !cmd) return
  chatQueue.push(cmd)
  log('CMD', cmd)
  processQueue(bot)
}

/*
 * فوری بدون صف - فقط برای وضعیت‌های حساس مثل /login
 */
function sendInstant(bot, text) {
  if (!bot) return
  try {
    bot.chat(text)
    lastChatTime = Date.now()
    log('INSTANT', text.startsWith('/login') ? '/login ***' : text)
  } catch (e) {
    log('MSG', `Instant send failed: ${e.message}`)
  }
}

module.exports = { sendToOwner, sendCommand, sendInstant }
