/*
 * Bilingual messages - پیام‌های دو زبانه (فارسی/انگلیسی)
 */

const M = {
  askLang: {
    fa: '🌐 لطفاً زبانو انتخاب کن:\n1 - فارسی\n2 - English\nبا !lang 1 یا !lang 2 انتخاب کن',
    en: '🌐 Please select language:\n1 - فارسی\n2 - English\nUse !lang 1 or !lang 2 to select'
  },
  langSet: {
    fa: '✅ زبان روی فارسی تنظیم شد',
    en: '✅ Language set to English'
  },
  notOwner: {
    fa: '⛔ فقط اونر میتونه این کامندو بزنه',
    en: '⛔ Only owner can run this command'
  },
  cooldown: {
    fa: (s) => `⏳ کول‌داون فعاله. ${s} ثانیه دیگه صبر کن`,
    en: (s) => `⏳ Cooldown active. Wait ${s} more seconds`
  },
  chatCooldown: {
    fa: '💬 لیمیت چت خورده. یکم صبر میکنم...',
    en: '💬 Chat limit hit. Waiting...'
  },
  tpaSent: {
    fa: '📤 درخواست تیپی به pvp_HS فرستاده شد',
    en: '📤 TPA request sent to pvp_HS'
  },
  tpaReceived: {
    fa: '📥 تیپی از pvp_HS اومد - قبول کردم',
    en: '📥 TPA from pvp_HS received - accepted'
  },
  tpaDenied: {
    fa: '❌ تیپی از فرد غیرمجاز رد شد',
    en: '❌ TPA from unauthorized player denied'
  },
  homeBedFound: {
    fa: (n) => `🛏️ ${n} تخت پیدا شد. میرم روی نزدیک‌ترین کلیک میکنم`,
    en: (n) => `🛏️ Found ${n} bed(s). Right-clicking the nearest one`
  },
  homeBedNotFound: {
    fa: '🛏️ هیچ تختی توی 16 بلاکی پیدا نشد',
    en: '🛏️ No bed found within 16 blocks'
  },
  homeSet: {
    fa: '✅ ریسپان روی تخت ست شد',
    en: '✅ Respawn point set on bed'
  },
  homeSetUnknown: {
    fa: '⚠️ روی تخت کلیک شد ولی پیام ست شدن نیومد - چک کن',
    en: '⚠️ Clicked bed but no confirmation - please check'
  },
  dropDone: {
    fa: (n) => `🗑️ ${n} آیتم دراپ شد. آرمور/الیترا/گلدن‌اپل و ۱ توتم نگه داشته شد`,
    en: (n) => `🗑️ Dropped ${n} items. Kept armor/elytra/golden apples and 1 totem`
  },
  autoTotem: {
    fa: '🛡️ AutoTotem: توتم به دست چپ منتقل شد',
    en: '🛡️ AutoTotem: totem moved to offhand'
  },
  modeSet: {
    fa: (n, name) => `🎮 مود ${n} (${name}) فعال شد`,
    en: (n, name) => `🎮 Mode ${n} (${name}) activated`
  },
  modeStop: {
    fa: '🛑 مود متوقف شد',
    en: '🛑 Mode stopped'
  },
  renderSet: {
    fa: (n) => `👁️ رندر دیستنس روی ${n} تنظیم شد`,
    en: (n) => `👁️ Render distance set to ${n}`
  },
  shulkerScanDone: {
    fa: (b, d, c, m) => `🔍 اسکن انجام شد. دکمه‌ها:${b} دیسپنسر:${d} چست:${c} ماین‌کارت:${m}`,
    en: (b, d, c, m) => `🔍 Scan complete. Buttons:${b} Dispensers:${d} Chests:${c} Carts:${m}`
  },
  shulkerCycleDone: {
    fa: (n) => `♻️ سیکل #${n} تموم شد`,
    en: (n) => `♻️ Cycle #${n} completed`
  },
  shulkerNoDevice: {
    fa: '⚠️ دستگاه شالکر فارم توی 16 بلاکی پیدا نشد',
    en: '⚠️ Shulker farm device not found in 16 blocks'
  },
  kitLooking: {
    fa: '🎁 میرم سراغ چست کیت pvp',
    en: '🎁 Going to PvP kit chest'
  },
  kitTaken: {
    fa: '📦 کیت pvp برداشته شد',
    en: '📦 PvP kit taken'
  },
  kitTotemTaken: {
    fa: '🛡️ شالکر توتم برداشته شد',
    en: '🛡️ Totem shulker taken'
  },
  kitReady: {
    fa: '✅ کیت آماده - دراپ شد. برای kill بگو !confirm',
    en: '✅ Kit ready - dropped. Say !confirm to /kill'
  },
  killed: {
    fa: '💀 /kill زده شد - میرم سراغ ریسپان',
    en: '💀 /kill executed - going to respawn'
  },
  awaitingConfirm: {
    fa: '⏸️ منتظر تایید !confirm هستم',
    en: '⏸️ Waiting for !confirm'
  },
  statsHeader: {
    fa: '📊 آمار بات',
    en: '📊 Bot Stats'
  }
}

function get(key, lang = 'fa', ...args) {
  const m = M[key]
  if (!m) return key
  const val = m[lang] || m.en || m.fa
  return typeof val === 'function' ? val(...args) : val
}

module.exports = { get, M }
