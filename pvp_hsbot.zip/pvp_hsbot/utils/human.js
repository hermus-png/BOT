/*
 * Human-like behavior utility
 * چرخش نرم سر، تاخیرهای متغیر، حرکت طبیعی
 */

const config = require('../config')

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms))
}

// تاخیر طبیعی متغیر
function humanDelay() {
  return sleep(randInt(config.timing.minReactionMs, config.timing.maxReactionMs))
}

// چرخش نرم سر به سمت یک نقطه یا موجودیت
async function lookAt(bot, target) {
  if (!bot || !bot.entity) return
  const pos = target.position || target
  try {
    await bot.lookAt(pos, true) // force = true تا واقعاً بچرخه
  } catch {}
  await sleep(randInt(150, 300))
}

// راست‌کلیک انسانی روی یه بلاک (اول سر میچرخه بعد کلیک)
async function humanRightClick(bot, block) {
  if (!block) return false
  await lookAt(bot, block.position.offset(0.5, 0.5, 0.5))
  await sleep(randInt(200, 500))
  try {
    await bot.activateBlock(block)
    return true
  } catch (e) {
    return false
  }
}

// چپ‌کلیک انسانی (زدن بلاک - برای دکمه‌ها فرقی نمیکنه)
async function humanLeftClick(bot, block) {
  if (!block) return false
  await lookAt(bot, block.position.offset(0.5, 0.5, 0.5))
  await sleep(randInt(200, 500))
  try {
    await bot.swingArm('right')
    await bot.dig(block, true)
    return true
  } catch {
    return false
  }
}

// یه چرخش کوچیک تصادفی برای طبیعی بودن
async function idleHeadMove(bot) {
  if (!bot?.entity) return
  const yaw = bot.entity.yaw + (Math.random() - 0.5) * 0.4
  const pitch = bot.entity.pitch + (Math.random() - 0.5) * 0.2
  try {
    await bot.look(yaw, pitch, false)
  } catch {}
}

module.exports = {
  randInt,
  sleep,
  humanDelay,
  lookAt,
  humanRightClick,
  humanLeftClick,
  idleHeadMove
}
