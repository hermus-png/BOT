'use strict'

/*
 * ═══════════════════════════════════════════════════════════════════════════
 *                       pvp_HSbot — 6b6t Mineflayer Bot
 *                              Owner: pvp_HS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * نسخه ۱.۰.۳ — فیکس invalid_player_movement در پورتال‌ها
 *
 * تغییرات اصلی این نسخه:
 *   1) حرکت دیگر با Timer خام شروع نمی‌شود. قبل از هر مرحله پورتال،
 *      بات منتظر سیگنال واقعی «همگام‌سازی با سرور مقصد» می‌ماند:
 *         login packet → spawn → اولین position packet (تلپورت تایید شد)
 *      فقط بعد از این سه تا، به سمت پورتال حرکت می‌کند.
 *   2) اگر حین راه رفتن، سرور شروع به انتقال (start_configuration) کند،
 *      همان لحظه حرکت قطع می‌شود و تا سینک شدن سرور جدید صبر می‌شود.
 *   3) ری‌کانکت با backoff نمایی + جیتر تا «You are logging in too fast» نیفتد.
 *   4) CAPTCHA / Anti-Bot دست نمی‌خورد — فقط لاگ و صبر.
 *
 * قانون پورتال (الگوی کد اصلی خودت حفظ شده):
 *   - Physics فقط موقع راه رفتن روشن است و بلافاصله بعد از توقف خاموش می‌شود.
 */

const mineflayer = require('mineflayer')
const { pathfinder } = require('mineflayer-pathfinder')

const config = require('./utils/config')
const { log, section } = require('./utils/logger')
const chatQueue = require('./utils/chatQueue')
const messages = require('./utils/messages')
const auth = require('./utils/auth')
const msg = require('./utils/msg')
const inv = require('./utils/inventory')
const tps = require('./utils/tps')

const homeCmd = require('./commands/home')
const dropCmd = require('./commands/drop')
const statsCmd = require('./commands/stats')
const renderCmd = require('./commands/render')
const helpCmd = require('./commands/help')
const tpaCmd = require('./commands/tpa')

const shulkerMode = require('./modes/shulker')
const kitMode = require('./modes/kit')

// ─────────────────────────────────────────────────────────────────
// STATE
// ─────────────────────────────────────────────────────────────────
let bot
let stopped = false
let loggedIn = false
let timers = []
let inConfiguration = false
let transferCount = 0
let portalsDone = false
let langAsked = false
let reconnectTimer = null
let connStableTimer = null
let reconnectAttempts = 0

/*
 * همگام‌سازی ماشین حالت انتقال:
 *  midHandshake    — توی فاز configuration هستیم (start_configuration تا login)
 *  spawnedInEpoch  — سرور فعلی event spawn داده
 *  posSynced       — اولین position packet از سرور فعلی اومده و تلپورت تایید شده (forcedMove)
 *  transferBegun   — start_configuration رسیده (جلوی راه رفتن گرفته می‌شود)
 *  portalRunning   — حلقه پورتال در حال اجراست
 */
let midHandshake = false
let spawnedInEpoch = false
let posSynced = false
let transferBegun = false
let portalRunning = false

const sleep = ms => new Promise(res => setTimeout(res, ms))

function timer(fn, ms) {
  const t = setTimeout(() => {
    if (!stopped) fn()
  }, ms)
  timers.push(t)
}

function clearTimers() {
  for (const t of timers) clearTimeout(t)
  timers = []
}

function stopMovement() {
  if (!bot) return
  try { bot.clearControlStates() } catch {}
  for (const key of ['forward', 'back', 'left', 'right', 'jump', 'sprint', 'sneak']) {
    try { bot.setControlState(key, false) } catch {}
  }
}

function pos() {
  if (!bot?.entity) return 'unknown'
  return `X=${bot.entity.position.x.toFixed(2)} Y=${bot.entity.position.y.toFixed(2)} Z=${bot.entity.position.z.toFixed(2)}`
}

function setPhysics(state) {
  try {
    bot.physicsEnabled = state
    log('PHYSICS', state ? 'ON' : 'OFF')
  } catch (e) {
    log('PHYSICS', `تغییر physics ممکن نشد: ${e.message}`)
  }
}

// ─────────────────────────────────────────────────────────────────
// RECONNECT — backoff نمایی + جیتر
// ─────────────────────────────────────────────────────────────────
const BACKOFF_BASE = [20000, 45000, 90000, 180000, 300000]

function scheduleReconnect() {
  if (reconnectTimer) return
  const idx = Math.min(reconnectAttempts, BACKOFF_BASE.length - 1)
  const jitter = Math.floor(Math.random() * 10000)
  const ms = BACKOFF_BASE[idx] + jitter
  reconnectAttempts++
  log('RECONNECT', `اتصال مجدد در ${Math.round(ms / 1000)} ثانیه (تلاش #${reconnectAttempts})`)
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null
    start()
  }, ms)
}

function resetReconnectBackoff() {
  reconnectAttempts = 0
}

// ─────────────────────────────────────────────────────────────────
// AUTOTOTEM LOOP (فقط بعد از پورتال دوم)
// ─────────────────────────────────────────────────────────────────
function startAutoTotem() {
  setInterval(async () => {
    if (!bot?.entity || stopped) return
    if (!config.get('settings.autoTotem')) return
    if (!portalsDone) return
    await inv.ensureTotemInOffhand(bot)
  }, 3000)
}

// ─────────────────────────────────────────────────────────────────
// COMMAND ROUTER
// ─────────────────────────────────────────────────────────────────
async function handleCommand(username, rawText) {
  if (!auth.isOwner(username)) {
    // سکوت کامل برای غیر مالک
    return
  }

  const text = rawText.trim()
  const parts = text.split(/\s+/)
  const cmd = parts[0].toLowerCase()
  const args = parts.slice(1)

  if (cmd === '!auth') {
    if (args.length === 0) {
      await msg.toOwner(bot, messages.t('needAuth'))
      return
    }
    const ok = auth.tryAuth(username, args.join(' '))
    if (ok) {
      await msg.toOwner(bot, messages.t('authOk'))
      if (!langAsked) {
        langAsked = true
        await msg.toOwner(bot, messages.t('langPrompt'))
      }
    } else {
      await msg.toOwner(bot, messages.t('authFail'))
    }
    return
  }

  if (langAsked && (text === '1' || text === '2')) {
    const lang = text === '1' ? 'fa' : 'en'
    messages.setLanguage(lang)
    langAsked = false
    await msg.toOwner(bot, lang === 'fa' ? '✅ زبان: فارسی' : '✅ Language: English')
    return
  }

  if (!auth.isAuthenticated(username)) {
    await msg.toOwner(bot, messages.t('needAuth'))
    return
  }

  if (cmd === '!help') return helpCmd.execute(bot)

  if (cmd === '!mode') {
    const m = parseInt(args[0])
    if (isNaN(m) || m < 0 || m > 2) {
      await msg.toOwner(bot, messages.t('modeInvalid'))
      return
    }
    if (shulkerMode.isRunning()) await shulkerMode.stop(bot)
    config.set('settings.currentMode', m)
    await msg.toOwner(bot, messages.t('modeChanged', m))
    return
  }

  if (cmd === '!tpa') return tpaCmd.sendTpaToOwner(bot)
  if (cmd === '!home') return homeCmd.execute(bot)
  if (cmd === '!drop') return dropCmd.execute(bot)
  if (cmd === '!stats') return statsCmd.execute(bot)
  if (cmd === '!render') return renderCmd.execute(bot, args)

  if (cmd === '!farm') {
    const mode = config.get('settings.currentMode')
    if (mode !== 1) {
      await msg.toOwner(bot, messages.t('modeInactive'))
      return
    }
    const sub = args[0]?.toLowerCase()
    if (sub === 'start')  return shulkerMode.start(bot)
    if (sub === 'stop')   return shulkerMode.stop(bot)
    if (sub === 'status') return shulkerMode.status(bot)
    if (sub === 'scan')   return shulkerMode.rescan(bot)
    await msg.toOwner(bot, 'استفاده: !farm start|stop|status|scan')
    return
  }

  if (cmd === '?kit') {
    const mode = config.get('settings.currentMode')
    if (mode !== 2) {
      await msg.toOwner(bot, messages.t('modeInactive'))
      return
    }
    if (args[0]?.toLowerCase() === 'pvp') return kitMode.runKit(bot)
    await msg.toOwner(bot, 'استفاده: ?kit pvp')
    return
  }

  if (cmd === '!confirm') {
    const mode = config.get('settings.currentMode')
    if (mode !== 2) {
      await msg.toOwner(bot, messages.t('modeInactive'))
      return
    }
    return kitMode.killSelf(bot)
  }

  await msg.toOwner(bot, messages.t('unknownCmd'))
}

// ─────────────────────────────────────────────────────────────────
// PORTAL ENGINE — حرکت فقط بعد از سینک واقعی با سرور مقصد
// ─────────────────────────────────────────────────────────────────

/*
 * منتظر می‌ماند تا سرور فعلی کاملاً سینک شود:
 * login → spawn → position ack (forcedMove)
 * اگر در این بین انتقال جدید شروع شود یا بات عوض شود، abort می‌شود.
 */
function waitForReady(timeoutMs) {
  return new Promise(resolve => {
    const myBot = bot
    const deadline = Date.now() + timeoutMs
    const iv = setInterval(() => {
      if (stopped || bot !== myBot || !bot?.entity) {
        clearInterval(iv)
        resolve(false)
        return
      }
      if (!midHandshake && spawnedInEpoch && posSynced) {
        clearInterval(iv)
        resolve(true)
        return
      }
      if (Date.now() >= deadline) {
        clearInterval(iv)
        log('READY', 'TIMEOUT در انتظار سینک سرور')
        resolve(false)
        return
      }
    }, 200)
  })
}

function releaseDrive() {
  stopMovement()
  setPhysics(false)
}

/*
 * راه رفتن یک مرحله پورتال.
 * حرکت ادامه دارد تا: (الف) انتقال واقعی شروع شود (start_configuration)
 * یا (ب) زمان‌آوت — دیگر با Timer خشک متوقف نمی‌شویم، خود سرور تعیین می‌کند.
 */
async function walkStage(durationMs, label) {
  const myBot = bot
  if (!myBot?.entity) return 'abort'

  transferBegun = false

  section(label)
  log('POS', pos())
  log('MOVE', `${label}: Moving forward`)

  setPhysics(true)
  bot.setControlState('forward', true)

  const start = Date.now()
  while (Date.now() - start < durationMs) {
    if (stopped || bot !== myBot || !bot?.entity) {
      releaseDrive()
      return 'abort'
    }
    if (transferBegun) {
      log('MOVE', `${label}: انتقال واقعی آغاز شد — حرکت قطع شد`)
      releaseDrive()
      return 'transferred'
    }
    await sleep(100)
  }

  releaseDrive()
  log('MOVE', `${label}: توقف (زمان‌آوت)`)
  log('POS', pos())
  return 'timeout'
}

async function portalRun() {
  if (portalRunning) return
  portalRunning = true

  // گیت ۱: سینک سرور فعلی (login-server / سرور اول)
  log('WAIT', 'منتظر سینک سرور قبل از Portal #1...')
  if (!(await waitForReady(25000))) {
    portalRunning = false
    return
  }

  // Portal #1
  const r1 = await walkStage(12000, 'PORTAL #1')

  if (r1 === 'transferred') {
    log('TRANSFER', 'انتقال حین Portal #1 مشاهده شد')
  }

  // صبر کوتاه (مثل کد اصلی) + گیت سینک سرور بعدی
  log('WAIT', 'صبر ۱۰ ثانیه + سینک سرور قبل از Portal #2...')
  await sleep(10000)
  if (!(await waitForReady(30000))) {
    portalRunning = false
    return
  }

  // Portal #2
  const r2 = await walkStage(12000, 'PORTAL #2')

  if (r2 === 'transferred') {
    log('TRANSFER', 'انتقال حین Portal #2 مشاهده شد')
  }

  // سکونت نهایی: منتظر سینک کامل سرور مقصد
  await sleep(3000)
  if (!(await waitForReady(30000))) {
    portalRunning = false
    return
  }

  portalRunning = false
  portalsDone = true
  initBotSystems()
}

function beginPortalRun() {
  if (stopped || !bot?.entity) return
  portalRun()
}

function initBotSystems() {
  section('BOT SYSTEMS READY')
  log('INIT', 'سیستم کامندها فعال شد')
  log('INIT', 'AutoTotem فعال')
  log('INIT', 'منتظر !auth از pvp_HS...')

  resetReconnectBackoff()

  timer(async () => {
    await msg.toOwner(bot, '🟢 بات آماده‌ست. برای شروع: !auth <رمز>')
  }, 2000)
}

// ─────────────────────────────────────────────────────────────────
// START
// ─────────────────────────────────────────────────────────────────
function start() {
  stopped = false
  loggedIn = false
  inConfiguration = false
  portalsDone = false
  langAsked = false
  midHandshake = false
  spawnedInEpoch = false
  posSynced = false
  transferBegun = false
  portalRunning = false
  auth.clearAuth()
  statsCmd.resetPlayTime()

  section('6b6t BOT STARTING')

  const cfg = config.load()
  log('CONFIG', `Server: ${cfg.server.host}:${cfg.server.port}`)
  log('CONFIG', `Username: ${cfg.account.username}`)
  log('CONFIG', `Minecraft: ${cfg.server.version}`)
  log('CONFIG', `Owner: ${cfg.owner.name}`)
  log('CONFIG', 'VPN/Proxy: NONE')

  bot = mineflayer.createBot({
    host: cfg.server.host,
    port: cfg.server.port,
    username: cfg.account.username,
    password: cfg.account.password,
    version: cfg.server.version,
    auth: 'offline',
    physicsEnabled: false
  })

  bot.loadPlugin(pathfinder)

  // بعد از ۶۰ ثانیه اتصال پایدار، بک‌آف ری‌کانکت ریست می‌شود
  if (connStableTimer) clearTimeout(connStableTimer)
  connStableTimer = setTimeout(() => {
    if (!stopped && bot?.entity) resetReconnectBackoff()
  }, 60000)

  // ═════ RAW PACKETS ═════
  bot._client.on('packet', (data, meta) => {
    const important = [
      'start_configuration',
      'select_known_packs',
      'registry_data',
      'finish_configuration',
      'login',
      'disconnect',
      'transfer'
    ]

    if (important.includes(meta.name)) {
      log('PACKET', meta.name)
    }

    if (meta.name === 'start_configuration') {
      transferCount++
      inConfiguration = true
      midHandshake = true
      spawnedInEpoch = false
      posSynced = false
      transferBegun = true

      section(`SERVER TRANSFER #${transferCount}`)
      log('TRANSFER', 'Configuration started')

      stopMovement()
      log('MOVE', 'Movement STOPPED for configuration')

      setPhysics(false)
    }

    if (meta.name === 'finish_configuration') {
      log('CONFIG', 'finish_configuration received')
    }

    /*
     * هر login packet (اولیه یا بعد از انتقال) یعنی سرور جدید آماده‌ی
     * گیم‌پلی است ولی هنوز position نگرفته‌ایم → posSynced=false
     * تا spawn و position بعدی بیاید.
     */
    if (meta.name === 'login') {
      inConfiguration = false
      midHandshake = false
      spawnedInEpoch = false
      posSynced = false

      if (transferCount > 0) {
        log('TRANSFER', `New server login received (transfer #${transferCount})`)
        timer(() => {
          if (stopped) return
          log('TRANSFER', 'Server transfer completed')
          log('POS', pos())
        }, 1000)
      } else {
        log('LOGIN', 'Initial login packet')
      }
    }

    if (meta.name === 'disconnect') {
      section('RAW DISCONNECT PACKET')
      try {
        console.log(JSON.stringify(data, null, 2))
      } catch {
        console.log(data)
      }
    }

    if (meta.name === 'update_time') {
      const time = data.time ?? data.worldTime
      if (typeof time === 'bigint') tps.updateFromWorldTime(Number(time))
      else if (typeof time === 'number') tps.updateFromWorldTime(time)
    }
  })

  // ═════ LOGIN ═════
  bot.on('login', () => {
    section('CONNECTED')
    log('LOGIN', 'Connection established')
  })

  // ═════ SPAWN ═════
  /*
   * spawn یعنی سرور فعلی health فرستاده و موجودیت ساخته شده.
   * هنوز physics روشن نمی‌شود — منتظر position ack (forcedMove) می‌مانیم.
   */
  bot.on('spawn', () => {
    section('SPAWN')
    log('POS', pos())

    spawnedInEpoch = true

    if (portalsDone && !inConfiguration) {
      setPhysics(true)
    } else {
      log('SERVER', 'منتظر position ack از سرور... physics OFF')
    }

    log('SERVER', 'Waiting for login...')
  })

  // ═════ FORCED MOVE (position ack از سرور) ═════
  /*
   * mineflayer وقتی position packet از سرور می‌گیرد، تلپورت را تایید می‌کند
   * (teleport_confirm / position_look) و event forcedMove صادر می‌شود.
   * این یعنی مختصات و فیزیک با سرور هماهنگ است — حالا می‌توان حرکت کرد.
   */
  bot.on('forcedMove', () => {
    posSynced = true
    log('SYNC', 'position از سرور دریافت و تایید شد')
  })

  // ═════ CHAT ═════
  bot.on('messagestr', async message => {
    if (!message || !message.trim()) return

    log('CHAT', message)

    const text = message.toLowerCase()

    if (
      !loggedIn &&
      (
        text.includes('please login') ||
        text.includes('/login <password>')
      )
    ) {
      log('AUTH', 'Server requested /login')

      timer(() => {
        if (stopped || loggedIn) return
        log('AUTH', 'Sending /login')
        bot.chat(`/login ${config.get('account.password')}`)
      }, 500)
    }

    if (
      !loggedIn &&
      (
        text.includes('you are now logged in') ||
        text.includes('successfully logged in')
      )
    ) {
      loggedIn = true

      section('LOGIN SUCCESS')
      log('AUTH', 'Account login confirmed')
      log('POS', pos())
      log('WAIT', 'Waiting 10 seconds before Portal #1')

      timer(() => {
        beginPortalRun()
      }, 10000)
    }

    // قبول خودکار TPA فقط از pvp_HS
    if (portalsDone) {
      const tpaFrom = tpaCmd.parseTpaRequest(message)
      if (tpaFrom) {
        log('TPA', `TPA از ${tpaFrom}`)
        await tpaCmd.acceptTpa(bot)
      }
    }

    // تشخیص لیمت چت
    if (
      text.includes('slow down') ||
      text.includes('chat cooldown') ||
      text.includes('too fast') ||
      text.includes('cannot send chat')
    ) {
      chatQueue.markLimited(5000)
    }
  })

  // ═════ WHISPER (/msg دریافتی) ═════
  bot.on('whisper', async (username, message) => {
    log('WHISPER', `${username}: ${message}`)
    if (!portalsDone) return
    await handleCommand(username, message)
  })

  // بعضی پیام‌های /msg از طریق message event میان
  bot.on('message', async (jsonMsg) => {
    try {
      const text = jsonMsg.toString()
      const match =
        text.match(/\[([^\s]+)\s*->\s*me\]\s*(.+)/i) ||
        text.match(/([^\s]+)\s+whispers to you:\s*(.+)/i) ||
        text.match(/^From\s+([^:]+):\s*(.+)/i) ||
        text.match(/^([^\s]+)\s+->\s+me:\s*(.+)/i)

      if (match) {
        const [, sender, body] = match
        if (portalsDone) await handleCommand(sender.trim(), body.trim())
      }
    } catch {}
  })

  // ═════ RESPAWN ═════
  bot.on('respawn', () => {
    section('RESPAWN')
    log('POS', pos())

    spawnedInEpoch = true

    if (portalsDone && !inConfiguration) {
      setPhysics(true)
    }
  })

  // ═════ KICK ═════
  bot.on('kicked', reason => {
    stopped = true
    clearTimers()
    stopMovement()

    section('KICKED')

    try {
      if (typeof reason === 'string') {
        console.log(reason)
      } else {
        console.log(JSON.stringify(reason, null, 2))
      }
    } catch {
      console.log(String(reason))
    }

    scheduleReconnect()
  })

  // ═════ END ═════
  bot.on('end', reason => {
    stopped = true
    clearTimers()
    stopMovement()

    section('CONNECTION ENDED')
    log('END', reason || 'socketClosed')

    scheduleReconnect()
  })

  // ═════ ERROR ═════
  bot.on('error', err => {
    section('BOT ERROR')
    console.error(err)
  })

  bot._client.on('error', err => {
    section('PROTOCOL ERROR')
    console.error(err)
  })

  startAutoTotem()
}

start()
