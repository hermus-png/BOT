# 🤖 pvp_HSbot v1.0.3 — 6b6t Bot

## تغییرات این نسخه (فیکس invalid_player_movement در Portal)

**قبل:** حرکت پورتال با Timer خشک شروع می‌شد → روی login-server یا حین انتقال، سرور کیک `multiplayer.disconnect.invalid_player_movement` می‌داد.

**حالا:** حرکت فقط بعد از **همگام‌سازی واقعی با سرور مقصد** شروع می‌شود:
1. پکت `login` سرور جدید دریافت شود
2. event `spawn` بیاید
3. اولین پکت `position` از سرور بیاید و تلپورت تایید شود (`forcedMove`)

و اگر حین راه رفتن سرور انتقال جدید شروع کند (`start_configuration`)، همان لحظه حرکت قطع شده و تا سینک سرور بعدی صبر می‌شود — نه فقط بر اساس تایمر.

**ری‌کانکت** هم با backoff نمایی + جیتر (۲۰ ثانیه → ۴۵ → ۹۰ → ۱۸۰ → ۳۰۰ + جیتر تا ۱۰ ثانیه) تا پیام «You are logging in too fast» تکرار نشود. شمارنده بعد از ۶۰ ثانیه اتصال پایدار ریست می‌شود.

CAPTCHA / Anti-Bot دست نمی‌خورد — فقط لاگ و صبر (ری‌کانکت خودکار).

## نصب روی VPS (root — بدون sudo)

```bash
cd /app/BOT1
pm2 delete pvp-hs-bot
rm -rf pvp_hs_bot
unzip BOT1_FIXED.zip
cd pvp_hs_bot
npm install
pm2 start index.js --name pvp-hs-bot
pm2 save
pm2 logs pvp-hs-bot
```

## کامندها (همه فقط در /msg pvp_HSbot)

| کامند | کار |
|-------|-----|
| `!auth AZHAN8585@#@#ABOL1234` | احراز هویت (هر ری‌استارت لازم) — بعدش عدد `1` بزن برای فارسی |
| `!mode 0/1/2` | بدون مود / شالکر فارم / کیت |
| `!tpa` | بات بهت تیپی میده |
| `!home` | پیدا کردن تخت + ست respawn |
| `!drop` | دراپ همه به‌جز ارمور/الیترا/گپل/توتم (AutoTotem فعال) |
| `!stats` | پینگ، TPS، IP، HP، غذا، ارمور، uptime |
| `!render <2-32>` | رندر دیستنس |
| `!help` | راهنما |
| **مود ۱:** `!farm start / stop / status / scan` | اسکن خودکار ۱۶ بلاک + سیکل کامل |
| **مود ۲:** `?kit pvp` سپس `!confirm` | کیت + تیپی + دراپ + kill |

TPA از pvp_HS خودکار قبول می‌شود. مختصات هیچ‌جا فرستاده نمی‌شود. فقط به pvp_HS جواب می‌دهد.
