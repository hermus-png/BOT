'use strict'

/*
 * مدیریت فایل config.json - ذخیره و بارگذاری تنظیمات
 */

const fs = require('fs')
const path = require('path')

const CONFIG_PATH = path.join(__dirname, '..', 'config.json')

let cache = null

function load() {
  if (cache) return cache
  try {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf8')
    cache = JSON.parse(raw)
    return cache
  } catch (e) {
    console.error('[CONFIG] خطا در بارگذاری config:', e.message)
    process.exit(1)
  }
}

function save() {
  if (!cache) return
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(cache, null, 2))
  } catch (e) {
    console.error('[CONFIG] خطا در ذخیره config:', e.message)
  }
}

function get(pathStr) {
  const cfg = load()
  const parts = pathStr.split('.')
  let val = cfg
  for (const p of parts) {
    if (val == null) return undefined
    val = val[p]
  }
  return val
}

function set(pathStr, value) {
  const cfg = load()
  const parts = pathStr.split('.')
  let obj = cfg
  for (let i = 0; i < parts.length - 1; i++) {
    if (obj[parts[i]] == null || typeof obj[parts[i]] !== 'object') {
      obj[parts[i]] = {}
    }
    obj = obj[parts[i]]
  }
  obj[parts[parts.length - 1]] = value
  save()
}

module.exports = { load, save, get, set }
