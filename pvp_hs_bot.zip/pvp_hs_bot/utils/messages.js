'use strict'

/*
 * پیام‌های دو زبانه - فارسی و انگلیسی
 */

const config = require('./config')

const MESSAGES = {
  fa: {
    langPrompt: 'زبان پیام رو انتخاب کن (پاسخ با شماره در /msg): 1) فارسی  2) English',
    needAuth: '⚠ اول باید احراز هویت کنی. دستور: !auth <رمز>',
    authOk: '✅ احراز هویت موفق. خوش اومدی اربابم.',
    authFail: '❌ رمز اشتباه بود.',
    notOwner: '⛔ من فقط به pvp_HS جواب میدم.',
    modeChanged: mode => `🔄 مود تغییر کرد به Mode ${mode}`,
    modeInvalid: '❌ شماره مود نامعتبره. فقط 0 / 1 / 2',
    tpaSent: '✅ درخواست تیپی به سمتت فرستادم.',
    tpaAccepted: '✅ تیپی رو قبول کردم.',
    tpaBlocked: '⏳ باید صبر کنی، لیمت تیپی خورده.',
    chatLimit: '⏳ لیمت چت خورده، صبر کن...',
    homeStart: '🏠 دارم دنبال تخت میگردم...',
    homeFound: '🛏 تخت پیدا شد، دارم راست‌کلیک میکنم...',
    homeSet: '✅ Respawn Point ست شد.',
    homeNotSet: '⚠ پیام ست شدن نیومد. احتمالاً موفق نبود.',
    homeNoBed: '❌ توی محدوده تختی پیدا نکردم.',
    dropDone: n => `✅ ${n} آیتم دراپ شد.`,
    kitReady: '🎒 کیت آماده شد و دراپ کردم. برای kill شدن !confirm بزن.',
    kitDone: '✅ کیل شدم و منتظرم.',
    kitNoGear: '❌ توی چست‌ها شالکر گیر مناسب پیدا نکردم.',
    kitNoTotem: '❌ شالکر توتم پیدا نکردم.',
    scanStart: '🔍 دارم اطراف رو اسکن میکنم...',
    scanDone: '✅ اسکن تمام شد.',
    scanNotFound: '❌ همه اجزا (دکمه/دیسپنسر/چست) پیدا نشد.',
    farmStarted: '🏭 مود شالکر فارم فعال شد.',
    farmStopped: '🛑 مود شالکر فارم متوقف شد.',
    farmCycleDone: n => `♻ سیکل ${n} تمام شد.`,
    renderSet: v => `📏 رندر دیستنس ${v} تنظیم شد.`,
    modeInactive: '⚠ این کامند فقط توی مود مربوطه کار میکنه.',
    unknownCmd: '❓ کامند ناشناخته. !help برای لیست.',
    autoTotemOn: '🛡 AutoTotem فعال شد.',
    autoTotemOff: '⚪ AutoTotem غیرفعاله (توتم نداری).'
  },
  en: {
    langPrompt: 'Choose message language (reply via /msg): 1) فارسی  2) English',
    needAuth: '⚠ Authenticate first. Use: !auth <password>',
    authOk: '✅ Authenticated. Welcome master.',
    authFail: '❌ Wrong password.',
    notOwner: '⛔ I only reply to pvp_HS.',
    modeChanged: mode => `🔄 Mode switched to ${mode}`,
    modeInvalid: '❌ Invalid mode number. Only 0 / 1 / 2',
    tpaSent: '✅ TPA request sent.',
    tpaAccepted: '✅ TPA accepted.',
    tpaBlocked: '⏳ TPA cooldown active.',
    chatLimit: '⏳ Chat limit hit, waiting...',
    homeStart: '🏠 Searching for a bed...',
    homeFound: '🛏 Bed found, right-clicking...',
    homeSet: '✅ Respawn point set.',
    homeNotSet: '⚠ Respawn confirm not received.',
    homeNoBed: '❌ No bed nearby.',
    dropDone: n => `✅ Dropped ${n} items.`,
    kitReady: '🎒 Kit ready & dropped. Send !confirm to kill.',
    kitDone: '✅ Killed, waiting at spawn.',
    kitNoGear: '❌ No gear shulker found in chests.',
    kitNoTotem: '❌ No totem shulker found.',
    scanStart: '🔍 Scanning surroundings...',
    scanDone: '✅ Scan complete.',
    scanNotFound: '❌ Missing components (button/dispenser/chest).',
    farmStarted: '🏭 Shulker farm mode started.',
    farmStopped: '🛑 Shulker farm stopped.',
    farmCycleDone: n => `♻ Cycle ${n} done.`,
    renderSet: v => `📏 Render distance set to ${v}.`,
    modeInactive: '⚠ This command only works in its own mode.',
    unknownCmd: '❓ Unknown command. Try !help',
    autoTotemOn: '🛡 AutoTotem enabled.',
    autoTotemOff: '⚪ AutoTotem inactive (no totem).'
  }
}

function t(key, ...args) {
  const lang = config.get('settings.language') || 'fa'
  const val = MESSAGES[lang]?.[key] ?? MESSAGES.fa[key] ?? key
  return typeof val === 'function' ? val(...args) : val
}

function setLanguage(lang) {
  if (lang !== 'fa' && lang !== 'en') return false
  config.set('settings.language', lang)
  return true
}

module.exports = { t, setLanguage, MESSAGES }
