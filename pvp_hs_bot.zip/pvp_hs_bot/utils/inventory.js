'use strict'

/*
 * توابع اینونتوری: AutoTotem، دراپ، تشخیص آیتم‌های محافظت‌شده
 */

const { log } = require('./logger')
const { delay, humanClickDelay } = require('./human')

const KEEP_ITEMS = new Set([
  'golden_apple',
  'enchanted_golden_apple',
  'elytra',
  'totem_of_undying'
])

const ARMOR_KEYWORDS = ['_helmet', '_chestplate', '_leggings', '_boots']

function isArmor(name) {
  return ARMOR_KEYWORDS.some(k => name.endsWith(k))
}

function isKeepItem(name) {
  if (!name) return false
  if (KEEP_ITEMS.has(name)) return true
  if (isArmor(name)) return true
  return false
}

function isMinecartChest(name) {
  return name === 'chest_minecart' || name === 'minecart_with_chest'
}

async function ensureTotemInOffhand(bot) {
  if (!bot?.inventory) return false

  const off = bot.inventory.slots[45]
  if (off && off.name === 'totem_of_undying') return true

  const totem = bot.inventory.items().find(i => i.name === 'totem_of_undying')
  if (!totem) return false

  try {
    await bot.equip(totem, 'off-hand')
    log('INV', 'توتم توی offhand قرار گرفت.')
    return true
  } catch (e) {
    log('INV', `خطای equip توتم: ${e.message}`)
    return false
  }
}

async function dropMinecartChests(bot) {
  const items = bot.inventory.items().filter(i => isMinecartChest(i.name))
  let count = 0
  for (const it of items) {
    try {
      await bot.tossStack(it)
      count++
      await humanClickDelay()
    } catch (e) {
      log('INV', `خطای دراپ ماین‌کارت: ${e.message}`)
    }
  }
  return count
}

module.exports = {
  isKeepItem,
  isArmor,
  isMinecartChest,
  ensureTotemInOffhand,
  dropMinecartChests,
  KEEP_ITEMS
}
