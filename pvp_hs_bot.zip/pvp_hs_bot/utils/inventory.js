'use strict'

/*
 * توابع مربوط به اینونتوری
 * - AutoTotem: توتم همیشه در دست چپ (offhand)
 * - تشخیص آیتم‌های محافظت‌شده برای دراپ
 * - دراپ ماین‌کارت‌چست
 */

const { log } = require('./logger')
const { delay, humanClickDelay } = require('./human')

// آیتم‌های که هرگز دراپ نمیشن
const KEEP_ITEMS = new Set([
  'golden_apple',
  'enchanted_golden_apple',
  'elytra',
  'totem_of_undying'
])

// همه ارمورها
const ARMOR_KEYWORDS = ['_helmet', '_chestplate', '_leggings', '_boots']

function isArmor(name) {
  return ARMOR_KEYWORDS.some(k => name.endsWith(k))
}

function isKeepItem(name) {
  if (!name) return false
  if (KEEP_ITEMS.has(name)) return true
  if (isArmor(name)) return true
  return false
}

function isMinecartChest(name) {
  return name === 'chest_minecart' || name === 'minecart_with_chest'
}

/*
 * AutoTotem: توتم رو توی offhand قرار میده
 */
async function ensureTotemInOffhand(bot) {
  if (!bot?.inventory) return false

  const off = bot.inventory.slots[45] // offhand slot
  if (off && off.name === 'totem_of_undying') return true

  const totem = bot.inventory.items().find(i => i.name === 'totem_of_undying')
  if (!totem) return false

  try {
    await bot.equip(totem, 'off-hand')
    log('INV', 'توتم توی offhand قرار گرفت.')
    return true
  } catch (e) {
    log('INV', `خطای equip توتم: ${e.message}`)
    return false
  }
}

/*
 * دراپ همه ماین‌کارت‌چست‌های اینونتوری
 */
async function dropMinecartChests(bot) {
  const items = bot.inventory.items().filter(i => isMinecartChest(i.name))
  let count = 0
  for (const it of items) {
    try {
      await bot.tossStack(it)
      count++
      await humanClickDelay()
    } catch (e) {
      log('INV', `خطای دراپ ماین‌کارت: ${e.message}`)
    }
  }
  return count
}

/*
 * دراپ همه آیتم‌ها به جز آیتم‌های محافظت‌شده
 * ارمورها هم توی slot خودشون می‌مونن
 */
async function dropAllExceptKeep(bot) {
  let count = 0
  const items = bot.inventory.items()
  for (const it of items) {
    if (isKeepItem(it.name)) continue
    try {
      await bot.tossStack(it)
      count++
      await humanClickDelay()
    } catch (e) {
      log('INV', `خطای دراپ: ${e.message}`)
    }
  }
  return count
}

/*
 * دراپ همه (حتی توتم و ارمور) - برای kit mode
 * قبل از /kill
 */
async function dropEverything(bot) {
  let count = 0
  // اول offhand
  try {
    const off = bot.inventory.slots[45]
    if (off) {
      // move offhand to main hand slot then toss
      await bot.unequip('off-hand')
      await delay(200)
    }
  } catch {}

  // ارمورها رو در بیار
  for (const slot of ['head', 'torso', 'legs', 'feet']) {
    try {
      await bot.unequip(slot)
      await delay(200)
    } catch {}
  }

  await delay(300)

  const items = bot.inventory.items()
  for (const it of items) {
    try {
      await bot.tossStack(it)
      count++
      await humanClickDelay()
    } catch {}
  }
  return count
}

module.exports = {
  isKeepItem,
  isArmor,
  isMinecartChest,
  ensureTotemInOffhand,
  dropMinecartChests,
  dropAllExceptKeep,
  dropEverything,
  KEEP_ITEMS
}
