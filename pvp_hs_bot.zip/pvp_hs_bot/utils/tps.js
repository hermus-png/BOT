'use strict'

/*
 * محاسبه TPS سرور از روی packet های time_update
 */

let lastWorldTime = null
let lastRealTime = null
let tpsSamples = []

function updateFromWorldTime(worldTime) {
  const now = Date.now()
  if (lastWorldTime !== null && lastRealTime !== null) {
    const realDelta = (now - lastRealTime) / 1000
    const worldDelta = worldTime - lastWorldTime
    if (realDelta > 0 && worldDelta > 0) {
      const tps = worldDelta / realDelta
      if (tps > 0 && tps <= 20.5) {
        tpsSamples.push(tps)
        if (tpsSamples.length > 20) tpsSamples.shift()
      }
    }
  }
  lastWorldTime = worldTime
  lastRealTime = now
}

function getTPS() {
  if (tpsSamples.length === 0) return 20.0
  const avg = tpsSamples.reduce((a, b) => a + b, 0) / tpsSamples.length
  return Math.min(20, Math.max(0, avg))
}

module.exports = { updateFromWorldTime, getTPS }
