'use strict'

/*
 * محاسبه TPS سرور از روی packet های time_update
 */

let lastTimeUpdate = 0
let tickCount = 0
let lastCalc = Date.now()
let currentTPS = 20.0

function onTimeUpdate() {
  const now = Date.now()
  tickCount++
  if (now - lastCalc >= 5000) {
    // در حالت ایده‌آل هر ثانیه 20 tick داریم
    currentTPS = (tickCount / ((now - lastCalc) / 1000))
    // ولی time_update هر ثانیه فقط یه بار میاد. پس روش دقیق‌تر: از رابطه سرور طرف deltatime
    tickCount = 0
    lastCalc = now
  }
}

// روش دقیق‌تر: بر اساس world time delta
let lastWorldTime = null
let lastRealTime = null
let tpsSamples = []

function updateFromWorldTime(worldTime) {
  const now = Date.now()
  if (lastWorldTime !== null && lastRealTime !== null) {
    const realDelta = (now - lastRealTime) / 1000
    const worldDelta = worldTime - lastWorldTime
    if (realDelta > 0 && worldDelta > 0) {
      const tps = worldDelta / realDelta
      if (tps > 0 && tps <= 20.5) {
        tpsSamples.push(tps)
        if (tpsSamples.length > 20) tpsSamples.shift()
      }
    }
  }
  lastWorldTime = worldTime
  lastRealTime = now
}

function getTPS() {
  if (tpsSamples.length === 0) return 20.0
  const avg = tpsSamples.reduce((a, b) => a + b, 0) / tpsSamples.length
  return Math.min(20, Math.max(0, avg))
}

module.exports = { updateFromWorldTime, getTPS }
