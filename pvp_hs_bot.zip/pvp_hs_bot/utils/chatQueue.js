'use strict'

/*
 * صف چت با تشخیص لیمت
 */

const { log } = require('./logger')
const config = require('./config')

class ChatQueue {
  constructor() {
    this.queue = []
    this.processing = false
    this.lastChatTime = 0
    this.chatLimited = false
    this.chatLimitedUntil = 0
  }

  async send(bot, message) {
    return new Promise(resolve => {
      this.queue.push({ bot, message, resolve })
      this.process()
    })
  }

  async process() {
    if (this.processing) return
    this.processing = true

    while (this.queue.length > 0) {
      const item = this.queue.shift()
      const cooldown = config.get('settings.chatCooldownMs') || 1500

      if (this.chatLimited && Date.now() < this.chatLimitedUntil) {
        const waitMs = this.chatLimitedUntil - Date.now()
        log('CHAT', `صبر برای لیمت چت: ${waitMs}ms`)
        await new Promise(r => setTimeout(r, waitMs))
        this.chatLimited = false
      }

      const sinceLast = Date.now() - this.lastChatTime
      if (sinceLast < cooldown) {
        await new Promise(r => setTimeout(r, cooldown - sinceLast))
      }

      try {
        item.bot.chat(item.message)
        this.lastChatTime = Date.now()
      } catch (e) {
        log('ERROR', `چت خطا: ${e.message}`)
      }

      item.resolve()
    }

    this.processing = false
  }

  markLimited(durationMs = 5000) {
    this.chatLimited = true
    this.chatLimitedUntil = Date.now() + durationMs
    log('CHAT', `لیمت چت مارک شد برای ${durationMs}ms`)
  }
}

module.exports = new ChatQueue()
