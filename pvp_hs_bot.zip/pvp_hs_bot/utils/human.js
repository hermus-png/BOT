'use strict'

/*
 * رفتار انسانی: کلیک با تاخیر، حرکت سر نرم، تایپ با تاخیر
 * سطح: متوسط (بالانس بین سرعت و طبیعی بودن)
 */

const config = require('./config')

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function delay(ms) {
  return new Promise(res => setTimeout(res, ms))
}

async function humanClickDelay() {
  const h = config.get('settings.humanization')
  await delay(randInt(h.clickDelayMinMs, h.clickDelayMaxMs))
}

/*
 * چرخش نرم سر به سمت یه نقطه
 * بجای snap به هدف، در چند فریم چرخش میکنه
 */
async function smoothLookAt(bot, targetPos) {
  const h = config.get('settings.humanization')
  const totalMs = randInt(h.headTurnMinMs, h.headTurnMaxMs)
  const steps = 6

  const dx = targetPos.x - bot.entity.position.x
  const dy = targetPos.y - (bot.entity.position.y + bot.entity.height)
  const dz = targetPos.z - bot.entity.position.z

  const targetYaw = Math.atan2(-dx, -dz)
  const targetPitch = Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))

  const startYaw = bot.entity.yaw
  const startPitch = bot.entity.pitch

  // کوتاه‌ترین راه چرخش
  let deltaYaw = targetYaw - startYaw
  while (deltaYaw > Math.PI) deltaYaw -= 2 * Math.PI
  while (deltaYaw < -Math.PI) deltaYaw += 2 * Math.PI

  const deltaPitch = targetPitch - startPitch

  const stepMs = Math.floor(totalMs / steps)

  for (let i = 1; i <= steps; i++) {
    // ease-in-out
    const p = i / steps
    const eased = p < 0.5 ? 2 * p * p : -1 + (4 - 2 * p) * p

    const yaw = startYaw + deltaYaw * eased
    const pitch = startPitch + deltaPitch * eased

    // یه ذره نویز که رفتار طبیعی‌تر بشه
    const jitterYaw = (Math.random() - 0.5) * 0.02
    const jitterPitch = (Math.random() - 0.5) * 0.01

    await bot.look(yaw + jitterYaw, pitch + jitterPitch, false)
    await delay(stepMs)
  }

  // چرخش نهایی دقیق
  await bot.look(targetYaw, targetPitch, true)
}

/*
 * تایپ با تاخیر (برای شبیه‌سازی تایپ انسانی)
 */
async function humanChat(bot, message) {
  const h = config.get('settings.humanization')
  const perChar = h.typingDelayPerCharMs
  const totalDelay = Math.min(perChar * message.length, 3000)
  await delay(totalDelay)
  bot.chat(message)
}

module.exports = { randInt, delay, humanClickDelay, smoothLookAt, humanChat }
