'use strict'

/*
 * فرستادن پیام خصوصی (/msg) — تمام نوتیفیکیشن‌ها فقط از این طریق میرن
 */

const chatQueue = require('./chatQueue')
const config = require('./config')

async function toOwner(bot, message) {
  const ownerName = config.get('owner.name') || 'pvp_HS'
  await chatQueue.send(bot, `/msg ${ownerName} ${message}`)
}

async function toPlayer(bot, playerName, message) {
  await chatQueue.send(bot, `/msg ${playerName} ${message}`)
}

module.exports = { toOwner, toPlayer }
