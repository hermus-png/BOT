'use strict'

/*
 * سیستم احراز هویت مالک
 * حتی اگه اسم درست بود، تا وقتی رمز درست نده هیچ کامندی اجرا نمیشه
 */

const config = require('./config')
const { log } = require('./logger')

let authenticatedNames = new Set()

function isOwner(username) {
  const owner = config.get('owner.name')
  return username === owner
}

function isAuthenticated(username) {
  return authenticatedNames.has(username)
}

function tryAuth(username, password) {
  if (!isOwner(username)) return false
  const real = config.get('owner.authPassword')
  if (password === real) {
    authenticatedNames.add(username)
    log('AUTH', `${username} احراز هویت شد.`)
    return true
  }
  return false
}

function clearAuth() {
  authenticatedNames.clear()
}

module.exports = { isOwner, isAuthenticated, tryAuth, clearAuth }
