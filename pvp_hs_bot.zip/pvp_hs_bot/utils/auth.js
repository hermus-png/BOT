'use strict'

/*
 * سیستم احراز هویت مالک
 * حتی اگه اسم درست بود (pvp_HS)، تا وقتی رمز درست نده به هیچ کامندی جواب نمیده
 */

const config = require('./config')
const { log } = require('./logger')

let authenticatedNames = new Set()

function isOwner(username) {
  const owner = config.get('owner.name')
  return username === owner
}

function isAuthenticated(username) {
  return authenticatedNames.has(username)
}

function tryAuth(username, password) {
  if (!isOwner(username)) return false
  const real = config.get('owner.authPassword')
  if (password === real) {
    authenticatedNames.add(username)
    log('AUTH', `${username} احراز هویت شد.`)
    return true
  }
  return false
}

function clearAuth() {
  authenticatedNames.clear()
}

function requireAuth(username) {
  return isOwner(username) && isAuthenticated(username)
}

module.exports = { isOwner, isAuthenticated, tryAuth, clearAuth, requireAuth }
