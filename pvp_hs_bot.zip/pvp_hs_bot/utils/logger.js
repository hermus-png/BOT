'use strict'

/*
 * سیستم لاگ با رنگ و برچسب + ذخیره در فایل
 * فقط توی کنسول - هیچ چیزی توی چت پابلیک نمیره
 */

const fs = require('fs')
const path = require('path')

const COLORS = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m'
}

const TYPE_COLORS = {
  INFO: COLORS.cyan,
  WARN: COLORS.yellow,
  ERROR: COLORS.red,
  OK: COLORS.green,
  DEBUG: COLORS.gray,
  MODE: COLORS.magenta,
  CMD: COLORS.blue,
  PACKET: COLORS.gray,
  AUTH: COLORS.yellow,
  CHAT: COLORS.green,
  MOVE: COLORS.cyan,
  SCAN: COLORS.magenta,
  KIT: COLORS.blue,
  FARM: COLORS.magenta,
  CONFIG: COLORS.cyan,
  PHYSICS: COLORS.yellow,
  TRANSFER: COLORS.magenta,
  LOGIN: COLORS.green,
  SERVER: COLORS.cyan,
  WAIT: COLORS.gray,
  POS: COLORS.gray,
  END: COLORS.red,
  INIT: COLORS.green,
  WHISPER: COLORS.magenta,
  TPA: COLORS.blue,
  INV: COLORS.cyan
}

const LOG_FILE = path.join(__dirname, '..', 'logs', `bot-${new Date().toISOString().slice(0, 10)}.log`)

function now() {
  return new Date().toLocaleTimeString('en-GB', { hour12: false })
}

function log(type, msg) {
  const color = TYPE_COLORS[type] || COLORS.reset
  const line = `[${now()}] [${type}] ${msg}`
  console.log(`${color}${line}${COLORS.reset}`)

  try {
    fs.appendFileSync(LOG_FILE, line + '\n')
  } catch {}
}

function section(title) {
  const bar = '='.repeat(64)
  console.log('\n' + COLORS.bright + bar + COLORS.reset)
  console.log(COLORS.bright + ` ${title}` + COLORS.reset)
  console.log(COLORS.bright + bar + COLORS.reset)

  try {
    fs.appendFileSync(LOG_FILE, `\n${bar}\n ${title}\n${bar}\n`)
  } catch {}
}

module.exports = { log, section }
