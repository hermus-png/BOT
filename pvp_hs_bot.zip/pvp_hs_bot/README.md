# 🤖 pvp_HSbot v1.0.2 — 6b6t Bot

**فیکس مهم این نسخه:** کیک `invalid_player_movement` حل شد. Physics حالا دقیقاً مثل کد پورتال خودت مدیریت میشه: خاموش روی login-server، فقط موقع راه رفتن داخل پورتال روشن، بلافاصله بعد از توقف خاموش. سیستم کامندها هم فقط بعد از پورتال دوم فعال میشه.

## نصب روی VPS (root — بدون sudo)

```bash
apt update
apt install -y unzip
cd /app/BOT1            # یا هر مسیر دیگه
pm2 delete pvp-hs-bot   # نسخه قبلی رو پاک کن
unzip -o pvp_hs_bot.zip
cd pvp_hs_bot
npm install
pm2 start index.js --name pvp-hs-bot
pm2 save
pm2 logs pvp-hs-bot
```

## کامندها (همه فقط در /msg pvp_HSbot)

| کامند | کار |
|-------|-----|
| `!auth AZHAN8585@#@#ABOL1234` | احراز هویت (هر ری‌استارت لازم) — بعدش عدد `1` بزن برای فارسی |
| `!mode 0/1/2` | بدون مود / شالکر فارم / کیت |
| `!tpa` | بات بهت تیپی میده |
| `!home` | پیدا کردن تخت + ست respawn |
| `!drop` | دراپ همه به‌جز ارمور/الیترا/گپل/توتم (AutoTotem فعال) |
| `!stats` | پینگ، TPS، IP، HP، غذا، ارمور، uptime |
| `!render <2-32>` | رندر دیستنس |
| `!help` | راهنما |
| **مود 1:** `!farm start / stop / status / scan` | اسکن خودکار ۱۶ بلاک + سیکل کامل |
| **مود 2:** `?kit pvp` سپس `!confirm` | کیت + تیپی + دراپ + kill |

TPA از pvp_HS خودکار قبول میشه. مختصات هیچ‌جا فرستاده نمیشه. فقط به pvp_HS جواب میده.
