# 🤖 pvp_HSbot — 6b6t Advanced Bot

بات پیشرفته ماینکرافت برای سرور **alt.6b6t.org** (نسخه 1.21.1)

---

## 📦 نصب روی VPS (دسترسی root — بدون sudo)

```bash
# ۱) نصب Node.js 20
apt update
apt install -y curl unzip build-essential
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# ۲) اکسترکت و نصب پکیج‌ها
cd /root
unzip pvp_hs_bot.zip
cd pvp_hs_bot
npm install

# ۳) تست اجرا
node index.js

# ۴) اجرای دائمی با pm2
npm install -g pm2
pm2 start index.js --name pvp-hs-bot
pm2 save
pm2 startup        # دستوری که برمی‌گردونه رو کپی و اجرا کن
pm2 logs pvp-hs-bot
```

---

## 📖 راهنمای کامل کامندها

> ⚠ همه کامندها فقط از طریق `/msg pvp_HSbot <command>` — چت پابلیک بی‌جوابه.

### 🔐 شروع (اجباری)
| کامند | توضیح |
|-------|-------|
| `!auth AZHAN8585@#@#ABOL1234` | احراز هویت — **هر ری‌استارت لازمه** |
| `1` یا `2` | بعد از auth، انتخاب زبان (۱=فارسی، ۲=انگلیسی) |

### 🎮 مودها
| کامند | توضیح |
|-------|-------|
| `!mode 0` | بدون مود — فقط کامندهای عمومی |
| `!mode 1` | مود شالکر فارم |
| `!mode 2` | مود کیت دادن |

### 📡 کامندهای عمومی (همه مودها)
| کامند | توضیح |
|-------|-------|
| `!tpa` | بات به تو `/tpa` می‌فرسته |
| `!home` | اسکن دنبال تخت + راست‌کلیک + ست respawn (پیام تایید در /msg) |
| `!drop` | دراپ همه به‌جز ارمور، الیترا، گلدن‌اپل، توتم (AutoTotem فعال) |
| `!stats` | Ping / TPS / IP / Uptime / HP / Food / Armor HP — همه در /msg |
| `!render <n>` | رندر دیستنس ۲ تا ۳۲ |
| `!help` | راهنمای کامل |

### 🏭 مود ۱ (شالکر فارم)
| کامند | توضیح |
|-------|-------|
| `!farm start` | شروع (اول اسکن خودکار ۱۶ بلاک) |
| `!farm stop` | توقف |
| `!farm status` | وضعیت + تعداد سیکل |
| `!farm scan` | اسکن مجدد دکمه/دیسپنسر/چست |

**سیکل:** دکمه ماین‌کارت → باز کردن ماین‌کارت‌چست → ریختن همه شالکرها (هر رنگ/اسمی) → بستن → دکمه فایربال → تکرار. ماین‌کارت‌چست‌های خالی اینونتوری خودکار دراپ میشن.

### 🎒 مود ۲ (کیت)
| کامند | توضیح |
|-------|-------|
| `?kit pvp` | بات شالکر گیر (کریستال+ندرایت+سورد+گپل) و شالکر توتم رو از چست‌های اطراف برمیداره، بهت تیپی میده، دراپ می‌کنه |
| `!confirm` | بعد از برداشتن کیت، بزن تا بات `/kill` بشه و برگرده ریسپاون |

### 🤝 TPA
بات TPA رو **خودکار و فقط از pvp_HS** قبول می‌کنه (پترن‌های EssentialsX: "wants to teleport", "has requested", "teleport to you").

---

## 🔒 امنیت
- فقط به `pvp_HS` جواب میده (بقیه سکوت کامل)
- حتی pvp_HS هم بدون `!auth` هیچ کامندی نمی‌تونه بزنه
- هیچ مختصاتی هیچ‌جا فرستاده نمیشه
- هیچ پیامی توی چت پابلیک نمیره
- Auto-reconnect بعد از kick (۳۰ ثانیه) و disconnect (۱۵ ثانیه)
- تشخیص لیمت چت و صبر خودکار

---

## 🗂 ساختار
```
pvp_hs_bot/
├── index.js            # ورودی + منطق پورتال ۱/۲ (دست‌نخورده)
├── config.json         # تنظیمات
├── package.json
├── utils/              # logger, config, messages, human, chatQueue, msg, auth, inventory, tps
├── commands/           # tpa, home, drop, stats, render, help
├── modes/              # shulker.js (مود ۱), kit.js (مود ۲)
└── logs/               # لاگ روزانه
```

---

## 🔧 عیب‌یابی
- **`sudo: command not found`** → تو root هستی، sudo نمیخواد
- **`Server version not supported`** → `config.json` رو چک کن، باید `"version": "1.21.1"` باشه
- **بات جواب نمیده** → اول `!auth` بزن
- **اسکن فارم چیزی پیدا نمیکنه** → بات باید حداکثر ۱۶ بلاک از دستگاه فاصله داشته باشه
- **لاگ زنده:** `pm2 logs pvp-hs-bot` یا `tail -f logs/bot-*.log`
