'use strict'

/*
 * !render <n> — تنظیم رندر دیستنس بات
 */

const config = require('../utils/config')
const { t } = require('../utils/messages')
const msg = require('../utils/msg')
const { log } = require('../utils/logger')

async function execute(bot, args) {
  const val = parseInt(args[0])
  if (isNaN(val) || val < 2 || val > 32) {
    await msg.toOwner(bot, '❌ رندر دیستنس باید بین 2 تا 32 باشه.')
    return
  }
  config.set('settings.renderDistance', val)

  try {
    bot._client.write('settings', {
      locale: 'en_US',
      viewDistance: val,
      chatFlags: 0,
      chatColors: true,
      skinParts: 0x7F,
      mainHand: 1,
      enableTextFiltering: false,
      enableServerListing: true
    })
    log('CMD', `رندر دیستنس ${val} تنظیم شد`)
  } catch (e) {
    log('CMD', `خطای تنظیم رندر: ${e.message}`)
  }

  await msg.toOwner(bot, t('renderSet', val))
}

module.exports = { execute }
