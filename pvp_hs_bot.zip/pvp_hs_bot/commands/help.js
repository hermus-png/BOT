'use strict'

/*
 * !help - لیست همه کامندها
 */

const msg = require('../utils/msg')
const config = require('../utils/config')

const HELP_FA = [
  '📖 ═══ راهنمای کامل کامندهای pvp_HSbot ═══',
  '',
  '🔐 !auth <رمز>    → احراز هویت (هر ری‌استارت باید بزنی)',
  '',
  '🎮 !mode 0        → غیرفعال کردن مود (کامندهای عمومی فعال)',
  '🎮 !mode 1        → مود شالکر فارم (دستگاه فایربال)',
  '🎮 !mode 2        → مود کیت دادن',
  '',
  '📡 !tpa           → بات به pvp_HS تیپی میده',
  '🏠 !home          → دنبال تخت میگرده و respawn ست میکنه',
  '📦 !drop          → دراپ همه (به جز ارمور/گلدن‌اپل/الیترا/توتم)',
  '📊 !stats         → آمار: پینگ، TPS، HP، غذا، ارمور، uptime',
  '📏 !render <n>    → رندر دیستنس (2-32)',
  '❓ !help          → همین راهنما',
  '',
  '🏭 مود 1 (شالکر فارم):',
  '   !farm start / !farm stop / !farm status',
  '   !farm scan    → دوباره اسکن اطراف',
  '',
  '🎒 مود 2 (کیت):',
  '   ?kit pvp       → بات کیت PvP رو میده',
  '   !confirm       → بعد از دریافت کیت این رو بزن تا /kill بشه',
  '',
  '⚠ توجه: تمام پاسخ‌ها فقط در /msg هستن.',
  '⚠ من فقط به pvp_HS جواب میدم.'
]

const HELP_EN = [
  '📖 ═══ pvp_HSbot Command Guide ═══',
  '',
  '🔐 !auth <password>  → Authenticate (required each restart)',
  '',
  '🎮 !mode 0           → No mode (general commands only)',
  '🎮 !mode 1           → Shulker Farm mode',
  '🎮 !mode 2           → Kit distribution mode',
  '',
  '📡 !tpa              → Bot sends /tpa to pvp_HS',
  '🏠 !home             → Find bed and set respawn',
  '📦 !drop             → Drop everything except armor/gapple/elytra/totem',
  '📊 !stats            → Ping, TPS, HP, food, armor, uptime',
  '📏 !render <n>       → Render distance (2-32)',
  '❓ !help             → This help',
  '',
  '🏭 Mode 1 (Shulker Farm):',
  '   !farm start / !farm stop / !farm status',
  '   !farm scan       → Rescan surroundings',
  '',
  '🎒 Mode 2 (Kit):',
  '   ?kit pvp          → Bot brings PvP kit',
  '   !confirm          → After receiving, send this to /kill',
  '',
  '⚠ Note: All responses via /msg only.',
  '⚠ I only respond to pvp_HS.'
]

async function execute(bot) {
  const lang = config.get('settings.language') || 'fa'
  const lines = lang === 'fa' ? HELP_FA : HELP_EN
  for (const line of lines) {
    await msg.toOwner(bot, line)
  }
}

module.exports = { execute }
