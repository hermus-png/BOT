'use strict'

/*
 * !help — لیست کامل کامندها در /msg
 */

const msg = require('../utils/msg')
const config = require('../utils/config')

const HELP_FA = [
  '📖 ═══ راهنمای کامندهای pvp_HSbot ═══',
  '🔐 !auth <رمز>  → احراز هویت (هر ری‌استارت لازم)',
  '🎮 !mode 0  → بدون مود (کامندهای عمومی)',
  '🎮 !mode 1  → مود شالکر فارم',
  '🎮 !mode 2  → مود کیت دادن',
  '📡 !tpa  → بات بهت تیپی میده',
  '🏠 !home  → پیدا کردن تخت و ست respawn',
  '📦 !drop  → دراپ همه به‌جز ارمور/گپل/الیترا/توتم',
  '📊 !stats  → پینگ، TPS، HP، غذا، ارمور',
  '📏 !render <n>  → رندر دیستنس (2-32)',
  '❓ !help  → همین راهنما',
  '🏭 مود 1: !farm start | stop | status | scan',
  '🎒 مود 2: ?kit pvp سپس !confirm',
  '⚠ همه پاسخ‌ها فقط در /msg — فقط به pvp_HS جواب میدم.'
]

const HELP_EN = [
  '📖 ═══ pvp_HSbot Command Guide ═══',
  '🔐 !auth <password>  → Authenticate (required each restart)',
  '🎮 !mode 0  → No mode (general commands)',
  '🎮 !mode 1  → Shulker Farm mode',
  '🎮 !mode 2  → Kit distribution mode',
  '📡 !tpa  → Bot sends /tpa to you',
  '🏠 !home  → Find bed and set respawn',
  '📦 !drop  → Drop all except armor/gapple/elytra/totem',
  '📊 !stats  → Ping, TPS, HP, food, armor',
  '📏 !render <n>  → Render distance (2-32)',
  '❓ !help  → This guide',
  '🏭 Mode 1: !farm start | stop | status | scan',
  '🎒 Mode 2: ?kit pvp then !confirm',
  '⚠ All responses via /msg — I only reply to pvp_HS.'
]

async function execute(bot) {
  const lang = config.get('settings.language') || 'fa'
  const lines = lang === 'fa' ? HELP_FA : HELP_EN
  for (const line of lines) {
    await msg.toOwner(bot, line)
  }
}

module.exports = { execute }
