'use strict'

/*
 * مدیریت TPA در 6b6t (EssentialsX)
 * - قبول خودکار TPA فقط از pvp_HS
 * - فرستادن TPA با !tpa
 */

const chatQueue = require('../utils/chatQueue')
const config = require('../utils/config')
const { log } = require('../utils/logger')
const { t } = require('../utils/messages')
const msg = require('../utils/msg')

let lastTpaSentTime = 0
let lastTpaAcceptTime = 0

function canSendTpa() {
  const cd = config.get('settings.tpaCooldownMs') || 5000
  return Date.now() - lastTpaSentTime > cd
}

function canAcceptTpa() {
  return Date.now() - lastTpaAcceptTime > 2000
}

function parseTpaRequest(message) {
  const owner = config.get('owner.name')
  const text = message.replace(/§./g, '').trim()

  const patterns = [
    new RegExp(`${owner}\\s+(wants to teleport|has requested|requested to teleport)`, 'i'),
    new RegExp(`${owner}.*teleport to you`, 'i'),
    new RegExp(`teleport request.*${owner}`, 'i')
  ]

  for (const p of patterns) {
    if (p.test(text)) return owner
  }
  return null
}

async function acceptTpa(bot) {
  if (!canAcceptTpa()) return
  lastTpaAcceptTime = Date.now()
  log('TPA', 'قبول کردن TPA از pvp_HS')
  await chatQueue.send(bot, '/tpaccept')
  await msg.toOwner(bot, t('tpaAccepted'))
}

async function sendTpaToOwner(bot) {
  if (!canSendTpa()) {
    await msg.toOwner(bot, t('tpaBlocked'))
    return false
  }
  lastTpaSentTime = Date.now()
  const owner = config.get('owner.name')
  log('TPA', `فرستادن /tpa به ${owner}`)
  await chatQueue.send(bot, `/tpa ${owner}`)
  await msg.toOwner(bot, t('tpaSent'))
  return true
}

module.exports = { parseTpaRequest, acceptTpa, sendTpaToOwner }
