'use strict'

/*
 * کامند !drop — دراپ همه به جز ارمور، الیترا، گلدن‌اپل، توتم
 */

const { log } = require('../utils/logger')
const { t } = require('../utils/messages')
const msg = require('../utils/msg')
const { humanClickDelay, delay } = require('../utils/human')
const { isKeepItem, ensureTotemInOffhand } = require('../utils/inventory')

async function execute(bot) {
  log('CMD', '!drop شروع شد')

  await ensureTotemInOffhand(bot)
  await delay(300)

  let count = 0
  const items = bot.inventory.items()

  for (const it of items) {
    if (isKeepItem(it.name)) continue

    try {
      await bot.tossStack(it)
      count++
      await humanClickDelay()
    } catch (e) {
      log('CMD', `خطای دراپ ${it.name}: ${e.message}`)
    }
  }

  await msg.toOwner(bot, t('dropDone', count))
  log('CMD', `${count} آیتم دراپ شد`)
}

module.exports = { execute }
