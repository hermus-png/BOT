'use strict'

/*
 * کامند !drop
 * دراپ همه آیتم‌ها به جز:
 * - Armor (helmet, chestplate, leggings, boots)
 * - Elytra
 * - Golden Apple / Enchanted Golden Apple
 * - یه توتم که همیشه توی offhand باشه (باقی توتم‌ها هم keep)
 */

const { log } = require('../utils/logger')
const { t } = require('../utils/messages')
const msg = require('../utils/msg')
const { humanClickDelay, delay } = require('../utils/human')
const { isKeepItem, ensureTotemInOffhand } = require('../utils/inventory')

async function execute(bot) {
  log('CMD', '!drop شروع شد')

  // اول توتم رو توی offhand قرار بده
  await ensureTotemInOffhand(bot)
  await delay(300)

  let count = 0
  const items = bot.inventory.items()

  for (const it of items) {
    // نگه داشتن آیتم‌های محافظت‌شده
    if (isKeepItem(it.name)) continue

    // یه توتم رو نگه دار (بقیه توتم‌ها اگه بیشتر از یکی بود، نگه)
    // (توتم توی offhand مستقل هست، اینا توی اینونتوری اصلی هستن)

    try {
      await bot.tossStack(it)
      count++
      await humanClickDelay()
    } catch (e) {
      log('CMD', `خطای دراپ ${it.name}: ${e.message}`)
    }
  }

  await msg.toOwner(bot, t('dropDone', count))
  log('CMD', `${count} آیتم دراپ شد`)
}

module.exports = { execute }
