'use strict'

/*
 * کامند !stats
 * ping، ip، سرعت نت، play time، HP، food، TPS و HP ارمور در /msg
 * هرگز مختصات نمیده
 */

const os = require('os')
const { log } = require('../utils/logger')
const msg = require('../utils/msg')
const config = require('../utils/config')
const { getTPS } = require('../utils/tps')

let startTime = Date.now()

function resetPlayTime() {
  startTime = Date.now()
}

function formatUptime(ms) {
  const s = Math.floor(ms / 1000)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return `${h}h ${m}m ${sec}s`
}

function getPing(bot) {
  try {
    if (bot.player && bot.player.ping !== undefined) return bot.player.ping
    return bot._client.latency || 'N/A'
  } catch {
    return 'N/A'
  }
}

function getIP() {
  try {
    const nets = os.networkInterfaces()
    for (const n of Object.values(nets)) {
      for (const info of n) {
        if (info.family === 'IPv4' && !info.internal) {
          return info.address
        }
      }
    }
    return '127.0.0.1'
  } catch {
    return 'N/A'
  }
}

function getArmorHP(bot) {
  try {
    const armor = {
      head: bot.inventory.slots[5],
      torso: bot.inventory.slots[6],
      legs: bot.inventory.slots[7],
      feet: bot.inventory.slots[8]
    }
    const parts = []
    for (const [slot, item] of Object.entries(armor)) {
      if (item) {
        const max = item.maxDurability || 0
        const cur = max - (item.durabilityUsed || 0)
        const pct = max > 0 ? Math.round((cur / max) * 100) : 100
        parts.push(`${slot}=${pct}%`)
      } else {
        parts.push(`${slot}=-`)
      }
    }
    return parts.join(' | ')
  } catch {
    return 'N/A'
  }
}

async function execute(bot) {
  log('CMD', '!stats اجرا شد')

  const ping = getPing(bot)
  const ip = getIP()
  const uptime = formatUptime(Date.now() - startTime)
  const hp = bot.health !== undefined ? bot.health.toFixed(1) : 'N/A'
  const food = bot.food !== undefined ? bot.food.toFixed(0) : 'N/A'
  const tps = getTPS().toFixed(1)
  const armor = getArmorHP(bot)
  const mode = config.get('settings.currentMode')
  const lang = config.get('settings.language')
  const lang_fa = lang === 'fa'

  const line1 = lang_fa
    ? `📊 آمار بات ► Ping: ${ping}ms | TPS: ${tps} | IP: ${ip}`
    : `📊 Bot Stats ► Ping: ${ping}ms | TPS: ${tps} | IP: ${ip}`

  const line2 = lang_fa
    ? `⏱ Uptime: ${uptime} | ❤ HP: ${hp}/20 | 🍗 Food: ${food}/20 | 🎮 Mode: ${mode}`
    : `⏱ Uptime: ${uptime} | ❤ HP: ${hp}/20 | 🍗 Food: ${food}/20 | 🎮 Mode: ${mode}`

  const line3 = `🛡 Armor: ${armor}`

  await msg.toOwner(bot, line1)
  await msg.toOwner(bot, line2)
  await msg.toOwner(bot, line3)
}

module.exports = { execute, resetPlayTime }
