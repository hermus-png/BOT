'use strict'

/*
 * کامند !home — اسکن برای تخت، راست‌کلیک، چک پیام respawn set
 */

const { log } = require('../utils/logger')
const { t } = require('../utils/messages')
const msg = require('../utils/msg')
const { smoothLookAt, delay, humanClickDelay } = require('../utils/human')

const BED_NAMES = [
  'white_bed', 'orange_bed', 'magenta_bed', 'light_blue_bed', 'yellow_bed',
  'lime_bed', 'pink_bed', 'gray_bed', 'light_gray_bed', 'cyan_bed',
  'purple_bed', 'blue_bed', 'brown_bed', 'green_bed', 'red_bed', 'black_bed'
]

function findNearestBed(bot, radius = 16) {
  const mcData = require('minecraft-data')(bot.version)
  const bedIds = BED_NAMES
    .map(n => mcData.blocksByName[n]?.id)
    .filter(id => id !== undefined)

  if (bedIds.length === 0) return null

  const blocks = bot.findBlocks({
    matching: bedIds,
    maxDistance: radius,
    count: 5
  })

  if (!blocks || blocks.length === 0) return null

  const sorted = blocks
    .map(p => ({ p, dist: bot.entity.position.distanceTo(p) }))
    .sort((a, b) => a.dist - b.dist)

  return bot.blockAt(sorted[0].p)
}

async function execute(bot) {
  await msg.toOwner(bot, t('homeStart'))
  log('CMD', '!home شروع شد')

  const bed = findNearestBed(bot, 16)
  if (!bed) {
    await msg.toOwner(bot, t('homeNoBed'))
    return
  }

  await msg.toOwner(bot, t('homeFound'))

  const dist = bot.entity.position.distanceTo(bed.position)
  if (dist > 4) {
    try {
      const { goals } = require('mineflayer-pathfinder')
      const goal = new goals.GoalNear(bed.position.x, bed.position.y, bed.position.z, 2)
      await bot.pathfinder.goto(goal)
    } catch (e) {
      log('CMD', `pathfinder خطا: ${e.message}, ادامه بدون حرکت`)
    }
  }

  await smoothLookAt(bot, bed.position.offset(0.5, 0.5, 0.5))
  await humanClickDelay()

  let respawnSet = false
  const listener = (message) => {
    const text = message.toString().toLowerCase()
    if (text.includes('respawn point set') ||
        text.includes('respawn point') ||
        text.includes('home set') ||
        text.includes('spawn point')) {
      respawnSet = true
    }
  }
  bot.on('messagestr', listener)

  try {
    await bot.activateBlock(bed)
  } catch (e) {
    log('CMD', `خطای کلیک روی تخت: ${e.message}`)
  }

  await delay(3000)
  bot.removeListener('messagestr', listener)

  if (respawnSet) {
    await msg.toOwner(bot, t('homeSet'))
  } else {
    await msg.toOwner(bot, t('homeNotSet'))
  }
}

module.exports = { execute }
