'use strict'

/*
 * ═══════════════════════════════════════════════════════════════════════════
 *                       pvp_HSbot — 6b6t Mineflayer Bot
 *                              Owner: pvp_HS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * نسخه ۱.۰.۲ — فیکس کیک invalid_player_movement
 *
 * قانون اصلی (دقیقاً مثل کد پورتال خودت):
 *   - Physics همیشه خاموشه، مگر موقع راه رفتن داخل پورتال
 *   - بعد از هر توقف حرکت، بلافاصله Physics خاموش میشه
 *   - روی login-server هیچ حرکتی انجام نمیشه (نه spawn، نه جای دیگه)
 *   - سیستم کامندها فقط بعد از پورتال دوم فعال میشه
 */

const mineflayer = require('mineflayer')
const { pathfinder } = require('mineflayer-pathfinder')

const config = require('./utils/config')
const { log, section } = require('./utils/logger')
const chatQueue = require('./utils/chatQueue')
const messages = require('./utils/messages')
const auth = require('./utils/auth')
const msg = require('./utils/msg')
const inv = require('./utils/inventory')
const tps = require('./utils/tps')

const homeCmd = require('./commands/home')
const dropCmd = require('./commands/drop')
const statsCmd = require('./commands/stats')
const renderCmd = require('./commands/render')
const helpCmd = require('./commands/help')
const tpaCmd = require('./commands/tpa')

const shulkerMode = require('./modes/shulker')
const kitMode = require('./modes/kit')

// ─────────────────────────────────────────────────────────────────
// STATE
// ─────────────────────────────────────────────────────────────────
let bot
let stopped = false
let loggedIn = false
let timers = []
let inConfiguration = false
let transferCount = 0
let portalsDone = false
let langAsked = false
let reconnectTimer = null

function timer(fn, ms) {
  const t = setTimeout(() => {
    if (!stopped) fn()
  }, ms)
  timers.push(t)
}

function clearTimers() {
  for (const t of timers) clearTimeout(t)
  timers = []
}

function stopMovement() {
  if (!bot) return
  try { bot.clearControlStates() } catch {}
  for (const key of ['forward', 'back', 'left', 'right', 'jump', 'sprint', 'sneak']) {
    try { bot.setControlState(key, false) } catch {}
  }
}

function pos() {
  if (!bot?.entity) return 'unknown'
  return `X=${bot.entity.position.x.toFixed(2)} Y=${bot.entity.position.y.toFixed(2)} Z=${bot.entity.position.z.toFixed(2)}`
}

function setPhysics(state) {
  try {
    bot.physicsEnabled = state
    log('PHYSICS', state ? 'ON' : 'OFF')
  } catch (e) {
    log('PHYSICS', `تغییر physics ممکن نشد: ${e.message}`)
  }
}

/*
 * ری‌کانکت امن — جلوی دو تا اتصال همزمان رو می‌گیره
 * (kicked و end هر دو fire میشن، بدون این guard دوتا بات ساخته میشد)
 */
function scheduleReconnect(ms) {
  if (reconnectTimer) return
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null
    start()
  }, ms)
}

// ─────────────────────────────────────────────────────────────────
// AUTOTOTEM LOOP (فقط بعد از پورتال دوم)
// ─────────────────────────────────────────────────────────────────
function startAutoTotem() {
  setInterval(async () => {
    if (!bot?.entity || stopped) return
    if (!config.get('settings.autoTotem')) return
    if (!portalsDone) return
    await inv.ensureTotemInOffhand(bot)
  }, 3000)
}

// ─────────────────────────────────────────────────────────────────
// COMMAND ROUTER
// ─────────────────────────────────────────────────────────────────
async function handleCommand(username, rawText) {
  if (!auth.isOwner(username)) {
    // سکوت کامل برای غیر مالک
    return
  }

  const text = rawText.trim()
  const parts = text.split(/\s+/)
  const cmd = parts[0].toLowerCase()
  const args = parts.slice(1)

  if (cmd === '!auth') {
    if (args.length === 0) {
      await msg.toOwner(bot, messages.t('needAuth'))
      return
    }
    const ok = auth.tryAuth(username, args.join(' '))
    if (ok) {
      await msg.toOwner(bot, messages.t('authOk'))
      if (!langAsked) {
        langAsked = true
        await msg.toOwner(bot, messages.t('langPrompt'))
      }
    } else {
      await msg.toOwner(bot, messages.t('authFail'))
    }
    return
  }

  if (langAsked && (text === '1' || text === '2')) {
    const lang = text === '1' ? 'fa' : 'en'
    messages.setLanguage(lang)
    langAsked = false
    await msg.toOwner(bot, lang === 'fa' ? '✅ زبان: فارسی' : '✅ Language: English')
    return
  }

  if (!auth.isAuthenticated(username)) {
    await msg.toOwner(bot, messages.t('needAuth'))
    return
  }

  if (cmd === '!help') return helpCmd.execute(bot)

  if (cmd === '!mode') {
    const m = parseInt(args[0])
    if (isNaN(m) || m < 0 || m > 2) {
      await msg.toOwner(bot, messages.t('modeInvalid'))
      return
    }
    if (shulkerMode.isRunning()) await shulkerMode.stop(bot)
    config.set('settings.currentMode', m)
    await msg.toOwner(bot, messages.t('modeChanged', m))
    return
  }

  if (cmd === '!tpa') return tpaCmd.sendTpaToOwner(bot)
  if (cmd === '!home') return homeCmd.execute(bot)
  if (cmd === '!drop') return dropCmd.execute(bot)
  if (cmd === '!stats') return statsCmd.execute(bot)
  if (cmd === '!render') return renderCmd.execute(bot, args)

  if (cmd === '!farm') {
    const mode = config.get('settings.currentMode')
    if (mode !== 1) {
      await msg.toOwner(bot, messages.t('modeInactive'))
      return
    }
    const sub = args[0]?.toLowerCase()
    if (sub === 'start')  return shulkerMode.start(bot)
    if (sub === 'stop')   return shulkerMode.stop(bot)
    if (sub === 'status') return shulkerMode.status(bot)
    if (sub === 'scan')   return shulkerMode.rescan(bot)
    await msg.toOwner(bot, 'استفاده: !farm start|stop|status|scan')
    return
  }

  if (cmd === '?kit') {
    const mode = config.get('settings.currentMode')
    if (mode !== 2) {
      await msg.toOwner(bot, messages.t('modeInactive'))
      return
    }
    if (args[0]?.toLowerCase() === 'pvp') return kitMode.runKit(bot)
    await msg.toOwner(bot, 'استفاده: ?kit pvp')
    return
  }

  if (cmd === '!confirm') {
    const mode = config.get('settings.currentMode')
    if (mode !== 2) {
      await msg.toOwner(bot, messages.t('modeInactive'))
      return
    }
    return kitMode.killSelf(bot)
  }

  await msg.toOwner(bot, messages.t('unknownCmd'))
}

// ─────────────────────────────────────────────────────────────────
// PORTAL LOGIC — دقیقاً بر اساس کد اصلی خودت
// Physics فقط موقع راه رفتن روشنه، بلافاصله بعد از توقف خاموش میشه
// ─────────────────────────────────────────────────────────────────
function portal1() {
  if (stopped || !bot.entity) return

  section('PORTAL #1')

  log('POS', pos())
  log('MOVE', 'Moving forward')

  setPhysics(true)
  bot.setControlState('forward', true)

  timer(() => {
    if (stopped) return

    stopMovement()
    setPhysics(false)

    log('MOVE', 'Stopped')
    log('POS', pos())
    log('WAIT', 'Waiting 10 seconds before Portal #2')

    timer(() => {
      portal2()
    }, 10000)

  }, 10000)
}

function portal2() {
  if (stopped || !bot.entity) return

  section('PORTAL #2')

  log('POS', pos())

  setPhysics(true)

  log('MOVE', 'Moving forward toward Portal #2')

  bot.setControlState('forward', true)

  timer(() => {
    if (stopped) return

    stopMovement()
    setPhysics(false)

    log('MOVE', 'Movement stopped')
    log('POS', pos())

    // ═══════════════════════════════════════════════
    // بعد از پورتال دوم: فعال شدن سیستم‌های بات
    // ═══════════════════════════════════════════════
    portalsDone = true
    initBotSystems()

  }, 10000)
}

function initBotSystems() {
  section('BOT SYSTEMS READY')
  log('INIT', 'سیستم کامندها فعال شد')
  log('INIT', 'AutoTotem فعال')
  log('INIT', 'منتظر !auth از pvp_HS...')

  timer(async () => {
    await msg.toOwner(bot, '🟢 بات آماده‌ست. برای شروع: !auth <رمز>')
  }, 2000)
}

// ─────────────────────────────────────────────────────────────────
// START
// ─────────────────────────────────────────────────────────────────
function start() {
  stopped = false
  loggedIn = false
  inConfiguration = false
  portalsDone = false
  langAsked = false
  auth.clearAuth()
  statsCmd.resetPlayTime()

  section('6b6t BOT STARTING')

  const cfg = config.load()
  log('CONFIG', `Server: ${cfg.server.host}:${cfg.server.port}`)
  log('CONFIG', `Username: ${cfg.account.username}`)
  log('CONFIG', `Minecraft: ${cfg.server.version}`)
  log('CONFIG', `Owner: ${cfg.owner.name}`)
  log('CONFIG', 'VPN/Proxy: NONE')

  bot = mineflayer.createBot({
    host: cfg.server.host,
    port: cfg.server.port,
    username: cfg.account.username,
    password: cfg.account.password,
    version: cfg.server.version,
    auth: 'offline',
    physicsEnabled: false
  })

  bot.loadPlugin(pathfinder)

  // ═════ RAW PACKETS ═════
  bot._client.on('packet', (data, meta) => {
    const important = [
      'start_configuration',
      'select_known_packs',
      'registry_data',
      'finish_configuration',
      'login',
      'disconnect',
      'transfer'
    ]

    if (important.includes(meta.name)) {
      log('PACKET', meta.name)
    }

    if (meta.name === 'start_configuration') {
      transferCount++
      inConfiguration = true

      section(`SERVER TRANSFER #${transferCount}`)
      log('TRANSFER', 'Configuration started')

      stopMovement()
      log('MOVE', 'Movement STOPPED for configuration')

      setPhysics(false)
    }

    if (meta.name === 'finish_configuration') {
      log('CONFIG', 'finish_configuration received')
    }

    /*
     * login بعد از configuration = انتقال به سرور جدید (نه login اولیه)
     * اینجا هم physics روشن نمی‌کنیم — فقط لاگ.
     * physics فقط داخل portal1/portal2 روشن میشه.
     */
    if (meta.name === 'login' && inConfiguration) {
      inConfiguration = false
      log('TRANSFER', 'New server login received')

      timer(() => {
        if (stopped) return
        log('TRANSFER', 'Server transfer completed')
        log('POS', pos())
      }, 1000)
    }

    if (meta.name === 'disconnect') {
      section('RAW DISCONNECT PACKET')
      try {
        console.log(JSON.stringify(data, null, 2))
      } catch {
        console.log(data)
      }
    }

    if (meta.name === 'update_time') {
      const time = data.time ?? data.worldTime
      if (typeof time === 'bigint') tps.updateFromWorldTime(Number(time))
      else if (typeof time === 'number') tps.updateFromWorldTime(time)
    }
  })

  // ═════ LOGIN ═════
  bot.on('login', () => {
    section('CONNECTED')
    log('LOGIN', 'Connection established')
  })

  // ═════ SPAWN ═════
  /*
   * خیلی مهم: اینجا physics روشن نمی‌کنیم!
   * روی login-server هر حرکتی = kick (invalid_player_movement)
   * physics فقط داخل portal1/portal2 و بعدش در دنیای اصلی روشن میشه.
   */
  bot.on('spawn', () => {
    section('SPAWN')
    log('POS', pos())

    if (portalsDone && !inConfiguration) {
      // فقط وقتی توی دنیای اصلی هستیم (بعد از پورتال‌ها)
      setPhysics(true)
    } else {
      log('SERVER', 'روی login-server هستیم — physics OFF')
    }

    log('SERVER', 'Waiting for login...')
  })

  // ═════ CHAT ═════
  bot.on('messagestr', async message => {
    if (!message || !message.trim()) return

    log('CHAT', message)

    const text = message.toLowerCase()

    if (
      !loggedIn &&
      (
        text.includes('please login') ||
        text.includes('/login <password>')
      )
    ) {
      log('AUTH', 'Server requested /login')

      timer(() => {
        if (stopped || loggedIn) return
        log('AUTH', 'Sending /login')
        bot.chat(`/login ${config.get('account.password')}`)
      }, 500)
    }

    if (
      !loggedIn &&
      (
        text.includes('you are now logged in') ||
        text.includes('successfully logged in')
      )
    ) {
      loggedIn = true

      section('LOGIN SUCCESS')
      log('AUTH', 'Account login confirmed')
      log('POS', pos())
      log('WAIT', 'Waiting 10 seconds before Portal #1')

      timer(() => {
        portal1()
      }, 10000)
    }

    // قبول خودکار TPA فقط از pvp_HS
    if (portalsDone) {
      const tpaFrom = tpaCmd.parseTpaRequest(message)
      if (tpaFrom) {
        log('TPA', `TPA از ${tpaFrom}`)
        await tpaCmd.acceptTpa(bot)
      }
    }

    // تشخیص لیمت چت
    if (
      text.includes('slow down') ||
      text.includes('chat cooldown') ||
      text.includes('too fast') ||
      text.includes('cannot send chat')
    ) {
      chatQueue.markLimited(5000)
    }
  })

  // ═════ WHISPER (/msg دریافتی) ═════
  bot.on('whisper', async (username, message) => {
    log('WHISPER', `${username}: ${message}`)
    if (!portalsDone) return
    await handleCommand(username, message)
  })

  // بعضی پیام‌های /msg از طریق message event میان
  bot.on('message', async (jsonMsg) => {
    try {
      const text = jsonMsg.toString()
      const match =
        text.match(/\[([^\s]+)\s*->\s*me\]\s*(.+)/i) ||
        text.match(/([^\s]+)\s+whispers to you:\s*(.+)/i) ||
        text.match(/^From\s+([^:]+):\s*(.+)/i) ||
        text.match(/^([^\s]+)\s+->\s+me:\s*(.+)/i)

      if (match) {
        const [, sender, body] = match
        if (portalsDone) await handleCommand(sender.trim(), body.trim())
      }
    } catch {}
  })

  // ═════ RESPAWN ═════
  bot.on('respawn', () => {
    section('RESPAWN')
    log('POS', pos())

    if (portalsDone && !inConfiguration) {
      setPhysics(true)
    }
  })

  // ═════ KICK ═════
  bot.on('kicked', reason => {
    stopped = true
    clearTimers()
    stopMovement()

    section('KICKED')

    try {
      if (typeof reason === 'string') {
        console.log(reason)
      } else {
        console.log(JSON.stringify(reason, null, 2))
      }
    } catch {
      console.log(String(reason))
    }

    scheduleReconnect(30000)
  })

  // ═════ END ═════
  bot.on('end', reason => {
    stopped = true
    clearTimers()
    stopMovement()

    section('CONNECTION ENDED')
    log('END', reason || 'socketClosed')

    scheduleReconnect(15000)
  })

  // ═════ ERROR ═════
  bot.on('error', err => {
    section('BOT ERROR')
    console.error(err)
  })

  bot._client.on('error', err => {
    section('PROTOCOL ERROR')
    console.error(err)
  })

  startAutoTotem()
}

start()
