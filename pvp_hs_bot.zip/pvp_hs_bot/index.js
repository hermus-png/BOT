'use strict'

/*
 * ═══════════════════════════════════════════════════════════════════════════
 *                       pvp_HSbot — 6b6t Mineflayer Bot
 *                              Owner: pvp_HS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * نسخه ماینکرافت: 1.21.1 (سرور 6b6t این ورژن رو قبول میکنه)
 */

const mineflayer = require('mineflayer')
const { pathfinder } = require('mineflayer-pathfinder')
const Vec3 = require('vec3')

const config = require('./utils/config')
const { log, section } = require('./utils/logger')
const chatQueue = require('./utils/chatQueue')
const messages = require('./utils/messages')
const auth = require('./utils/auth')
const msg = require('./utils/msg')
const human = require('./utils/human')
const inv = require('./utils/inventory')
const tps = require('./utils/tps')

const homeCmd = require('./commands/home')
const dropCmd = require('./commands/drop')
const statsCmd = require('./commands/stats')
const renderCmd = require('./commands/render')
const helpCmd = require('./commands/help')
const tpaCmd = require('./commands/tpa')

const shulkerMode = require('./modes/shulker')
const kitMode = require('./modes/kit')

// ─────────────────────────────────────────────────────────────────
let bot
let stopped = false
let loggedIn = false
let timers = []
let inConfiguration = false
let transferCount = 0
let portalsDone = false
let langAsked = false

function timer(fn, ms) {
  const t = setTimeout(() => {
    if (!stopped) fn()
  }, ms)
  timers.push(t)
}

function clearTimers() {
  for (const t of timers) clearTimeout(t)
  timers = []
}

function stopMovement() {
  if (!bot) return
  try { bot.clearControlStates() } catch {}
  for (const key of ['forward', 'back', 'left', 'right', 'jump', 'sprint', 'sneak']) {
    try { bot.setControlState(key, false) } catch {}
  }
}

function pos() {
  if (!bot?.entity) return 'unknown'
  return `X=${bot.entity.position.x.toFixed(2)} Y=${bot.entity.position.y.toFixed(2)} Z=${bot.entity.position.z.toFixed(2)}`
}

function setPhysics(state) {
  try {
    bot.physicsEnabled = state
    log('PHYSICS', state ? 'ON' : 'OFF')
  } catch (e) {
    log('PHYSICS', `تغییر physics ممکن نشد: ${e.message}`)
  }
}

// ─────────────────────────────────────────────────────────────────
function startAutoTotem() {
  setInterval(async () => {
    if (!bot?.entity || stopped) return
    if (!config.get('settings.autoTotem')) return
    if (!portalsDone) return
    await inv.ensureTotemInOffhand(bot)
  }, 3000)
}

// ─────────────────────────────────────────────────────────────────
async function handleCommand(username, rawText) {
  if (!auth.isOwner(username)) {
    return
  }

  const text = rawText.trim()
  const parts = text.split(/\s+/)
  const cmd = parts[0].toLowerCase()
  const args = parts.slice(1)

  if (cmd === '!auth') {
    if (args.length === 0) {
      await msg.toOwner(bot, messages.t('needAuth'))
      return
    }
    const password = args.join(' ')
    const ok = auth.tryAuth(username, password)
    if (ok) {
      await msg.toOwner(bot, messages.t('authOk'))
      if (!langAsked) {
        langAsked = true
        await msg.toOwner(bot, messages.t('langPrompt'))
      }
    } else {
      await msg.toOwner(bot, messages.t('authFail'))
    }
    return
  }

  if (langAsked && (text === '1' || text === '2')) {
    const lang = text === '1' ? 'fa' : 'en'
    messages.setLanguage(lang)
    langAsked = false
    await msg.toOwner(bot, lang === 'fa' ? '✅ زبان: فارسی' : '✅ Language: English')
    return
  }

  if (!auth.isAuthenticated(username)) {
    await msg.toOwner(bot, messages.t('needAuth'))
    return
  }

  if (cmd === '!help') return helpCmd.execute(bot)

  if (cmd === '!mode') {
    const m = parseInt(args[0])
    if (isNaN(m) || m < 0 || m > 2) {
      await msg.toOwner(bot, messages.t('modeInvalid'))
      return
    }
    if (shulkerMode.isRunning()) await shulkerMode.stop(bot)
    config.set('settings.currentMode', m)
    await msg.toOwner(bot, messages.t('modeChanged', m))
    return
  }

  if (cmd === '!tpa') return tpaCmd.sendTpaToOwner(bot)
  if (cmd === '!home') return homeCmd.execute(bot)
  if (cmd === '!drop') return dropCmd.execute(bot)
  if (cmd === '!stats') return statsCmd.execute(bot)
  if (cmd === '!render') return renderCmd.execute(bot, args)

  if (cmd === '!farm') {
    const mode = config.get('settings.currentMode')
    if (mode !== 1) {
      await msg.toOwner(bot, messages.t('modeInactive'))
      return
    }
    const sub = args[0]?.toLowerCase()
    if (sub === 'start')  return shulkerMode.start(bot)
    if (sub === 'stop')   return shulkerMode.stop(bot)
    if (sub === 'status') return shulkerMode.status(bot)
    if (sub === 'scan')   return shulkerMode.rescan(bot)
    await msg.toOwner(bot, 'استفاده: !farm start|stop|status|scan')
    return
  }

  if (cmd === '?kit') {
    const mode = config.get('settings.currentMode')
    if (mode !== 2) {
      await msg.toOwner(bot, messages.t('modeInactive'))
      return
    }
    if (args[0]?.toLowerCase() === 'pvp') return kitMode.runKit(bot)
    await msg.toOwner(bot, 'استفاده: ?kit pvp')
    return
  }

  if (cmd === '!confirm') {
    const mode = config.get('settings.currentMode')
    if (mode !== 2) {
      await msg.toOwner(bot, messages.t('modeInactive'))
      return
    }
    return kitMode.killSelf(bot)
  }

  await msg.toOwner(bot, messages.t('unknownCmd'))
}

// ─────────────────────────────────────────────────────────────────
function portal1() {
  if (stopped || !bot.entity) return
  section('PORTAL #1')
  log('POS', pos())
  log('MOVE', 'حرکت به جلو')
  setPhysics(true)
  bot.setControlState('forward', true)

  timer(() => {
    if (stopped) return
    stopMovement()
    log('MOVE', 'ایست')
    log('POS', pos())
    log('WAIT', 'صبر 10 ثانیه قبل از پورتال 2')
    timer(() => portal2(), 10000)
  }, 10000)
}

function portal2() {
  if (stopped || !bot.entity) return
  section('PORTAL #2')
  log('POS', pos())
  setPhysics(true)
  log('MOVE', 'حرکت به سمت پورتال 2')
  bot.setControlState('forward', true)

  timer(() => {
    if (stopped) return
    stopMovement()
    log('MOVE', 'ایست')
    log('POS', pos())

    portalsDone = true
    initBotSystems()
  }, 10000)
}

function initBotSystems() {
  section('BOT SYSTEMS READY')
  log('INIT', 'سیستم کامندها فعال شد')
  log('INIT', 'AutoTotem فعال')
  log('INIT', 'منتظر !auth از pvp_HS...')

  timer(async () => {
    await msg.toOwner(bot, '🟢 بات آماده‌ست. برای شروع: !auth <رمز>')
  }, 2000)
}

// ─────────────────────────────────────────────────────────────────
function start() {
  stopped = false
  loggedIn = false
  inConfiguration = false
  portalsDone = false
  auth.clearAuth()
  statsCmd.resetPlayTime()

  section('6b6t BOT STARTING')

  const cfg = config.load()
  log('CONFIG', `Server: ${cfg.server.host}:${cfg.server.port}`)
  log('CONFIG', `Username: ${cfg.account.username}`)
  log('CONFIG', `Minecraft: ${cfg.server.version}`)
  log('CONFIG', `Owner: ${cfg.owner.name}`)

  bot = mineflayer.createBot({
    host: cfg.server.host,
    port: cfg.server.port,
    username: cfg.account.username,
    password: cfg.account.password,
    version: cfg.server.version,
    auth: 'offline',
    physicsEnabled: false
  })

  bot.loadPlugin(pathfinder)

  // ═════ RAW PACKETS ═════
  bot._client.on('packet', (data, meta) => {
    const important = [
      'start_configuration', 'select_known_packs', 'registry_data',
      'finish_configuration', 'login', 'disconnect', 'transfer'
    ]
    if (important.includes(meta.name)) log('PACKET', meta.name)

    if (meta.name === 'start_configuration') {
      transferCount++
      inConfiguration = true
      section(`SERVER TRANSFER #${transferCount}`)
      log('TRANSFER', 'Configuration started')
      stopMovement()
      log('MOVE', 'حرکت متوقف شد برای configuration')
      setPhysics(false)
    }

    if (meta.name === 'finish_configuration') {
      log('CONFIG', 'finish_configuration دریافت شد')
    }

    if (meta.name === 'login' && inConfiguration) {
      inConfiguration = false
      log('TRANSFER', 'ورود جدید به سرور')
      timer(() => {
        if (stopped) return
        setPhysics(true)
        log('TRANSFER', 'انتقال سرور کامل شد')
        log('POS', pos())
      }, 1000)
    }

    if (meta.name === 'disconnect') {
      section('RAW DISCONNECT PACKET')
      try { console.log(JSON.stringify(data, null, 2)) } catch { console.log(data) }
    }

    if (meta.name === 'update_time' || meta.name === 'time') {
      const time = data.time || data.worldTime
      if (typeof time === 'bigint') tps.updateFromWorldTime(Number(time))
      else if (typeof time === 'number') tps.updateFromWorldTime(time)
    }
  })

  // ═════ LOGIN ═════
  bot.on('login', () => {
    section('CONNECTED')
    log('LOGIN', 'اتصال برقرار شد')
  })

  // ═════ SPAWN ═════
  bot.on('spawn', () => {
    section('SPAWN')
    log('POS', pos())
    if (!inConfiguration) setPhysics(true)
    log('SERVER', 'منتظر لاگین سرور...')
  })

  // ═════ CHAT ═════
  bot.on('messagestr', async (message) => {
    if (!message || !message.trim()) return
    log('CHAT', message)

    const text = message.toLowerCase()

    if (!loggedIn && (text.includes('please login') || text.includes('/login <password>'))) {
      log('AUTH', 'سرور /login خواست')
      timer(() => {
        if (stopped || loggedIn) return
        log('AUTH', 'ارسال /login')
        bot.chat(`/login ${config.get('account.password')}`)
      }, 500)
    }

    if (!loggedIn && (text.includes('you are now logged in') || text.includes('successfully logged in'))) {
      loggedIn = true
      section('LOGIN SUCCESS')
      log('AUTH', 'لاگین اکانت تایید شد')
      log('POS', pos())
      log('WAIT', 'صبر 10 ثانیه قبل از پورتال 1')
      timer(() => portal1(), 10000)
    }

    if (portalsDone) {
      const tpaFrom = tpaCmd.parseTpaRequest(message)
      if (tpaFrom) {
        log('TPA', `TPA از ${tpaFrom}`)
        await tpaCmd.acceptTpa(bot)
      }
    }

    if (text.includes('slow down') || text.includes('chat cooldown') || text.includes('too fast')) {
      chatQueue.markLimited(5000)
    }
  })

  // whisper events
  bot.on('whisper', async (username, message) => {
    log('WHISPER', `${username}: ${message}`)
    if (!portalsDone) return
    await handleCommand(username, message)
  })

  // بعضی سرورها whisper رو از طریق message هم میفرستن
  bot.on('message', async (jsonMsg) => {
    try {
      const text = jsonMsg.toString()
      let match = text.match(/\[([^\s]+)\s*->\s*me\]\s*(.+)/i)
                || text.match(/([^\s]+)\s+whispers to you:\s*(.+)/i)
                || text.match(/^From\s+([^:]+):\s*(.+)/i)
                || text.match(/^([^\s]+)\s+->\s+me:\s*(.+)/i)
      if (match) {
        const [, sender, body] = match
        if (portalsDone) await handleCommand(sender.trim(), body.trim())
      }
    } catch {}
  })

  // ═════ RESPAWN ═════
  bot.on('respawn', () => {
    section('RESPAWN')
    log('POS', pos())
    if (!inConfiguration) setPhysics(true)
  })

  // ═════ KICK ═════
  bot.on('kicked', reason => {
    stopped = true
    clearTimers()
    stopMovement()
    section('KICKED')
    try {
      console.log(typeof reason === 'string' ? reason : JSON.stringify(reason, null, 2))
    } catch { console.log(String(reason)) }

    setTimeout(() => start(), 30000)
  })

  // ═════ END ═════
  bot.on('end', reason => {
    stopped = true
    clearTimers()
    stopMovement()
    section('CONNECTION ENDED')
    log('END', reason || 'socketClosed')

    setTimeout(() => start(), 15000)
  })

  // ═════ ERROR ═════
  bot.on('error', err => {
    section('BOT ERROR')
    console.error(err)
  })

  bot._client.on('error', err => {
    section('PROTOCOL ERROR')
    console.error(err)
  })

  startAutoTotem()
}

start()
