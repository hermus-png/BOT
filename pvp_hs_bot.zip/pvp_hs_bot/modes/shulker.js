'use strict'

/*
 * ═══════════════════════════════════════════════════════════════════
 *   MODE 1: SHULKER FARM
 * ═══════════════════════════════════════════════════════════════════
 *
 * دستگاه: دو دکمه + یک دیسپنسر + یک چست + محل ماین‌کارت
 *
 *   دکمه 1 (Button #1)  →  یه Chest Minecart جلوی دیسپنسر می‌ذاره
 *                          (باید توسط پلیر ست بشه ولی وقتی زده شد دستگاه ماین‌کارت میسازه)
 *   دکمه 2 (Button #2)  →  دیسپنسر Fireball می‌ندازه و ماین‌کارت رو منفجر میکنه
 *
 * چرخه بات:
 *   1) کلیک روی دکمه 1  →  ماین‌کارت‌چست جلو ظاهر میشه
 *   2) کلیک روی ماین‌کارت‌چست (بازش کن)
 *   3) همه شالکرها رو از اینونتوری بذار داخل ماین‌کارت‌چست
 *      (فرقی نداره چه رنگی یا چه اسمی)
 *   4) اگه توی اینونتوری خودش هم ماین‌کارت‌چست خالی بود، دراپش کنه
 *   5) کلیک روی دکمه 2  →  فایربال شلیک و انفجار
 *   6) صبر تا شالکرها به چست اصلی بیفتن
 *   7) تکرار
 *
 * تشخیص خودکار:
 *   - اسکن 16 بلاک اطراف
 *   - پیدا کردن Chest و Dispenser
 *   - پیدا کردن دو Button (روی دیوار)
 *   - تشخیص کدوم دکمه به کدوم چیز وصله:
 *       * دکمه‌ای که نزدیک‌تر به دیسپنسر هست  = دکمه فایربال (Button #2)
 *       * دکمه‌ای که دورتر (یا نزدیک محل ماین‌کارت) = دکمه ماین‌کارت (Button #1)
 *   - این logic ساده ممکنه توی چیدمان‌های خاص اشتباه کنه؛
 *     پس بعد از اسکن گزارش میفرسته که تایید کنی
 */

const Vec3 = require('vec3')
const { log } = require('../utils/logger')
const { t } = require('../utils/messages')
const msg = require('../utils/msg')
const config = require('../utils/config')
const { delay, smoothLookAt, humanClickDelay, randInt } = require('../utils/human')
const { isMinecartChest, dropMinecartChests } = require('../utils/inventory')

let running = false
let stopFlag = false
let scanned = false
let mapping = null  // { chest, dispenser, buttonMinecartChest, buttonFireball }
let cycleCount = 0

/*
 * اسکن اطراف - پیدا کردن اجزای دستگاه
 */
async function scanArea(bot) {
  scanned = false
  await msg.toOwner(bot, t('scanStart'))
  log('SCAN', 'شروع اسکن ۱۶ بلاکی اطراف...')

  const mcData = require('minecraft-data')(bot.version)
  const radius = 16

  const chestBlocks = bot.findBlocks({
    matching: [mcData.blocksByName.chest.id, mcData.blocksByName.trapped_chest?.id].filter(Boolean),
    maxDistance: radius,
    count: 20
  })

  const dispenserBlocks = bot.findBlocks({
    matching: [mcData.blocksByName.dispenser.id],
    maxDistance: radius,
    count: 5
  })

  // انواع دکمه
  const buttonNames = Object.keys(mcData.blocksByName).filter(n => n.endsWith('_button'))
  const buttonIds = buttonNames.map(n => mcData.blocksByName[n].id).filter(Boolean)

  const buttonBlocks = bot.findBlocks({
    matching: buttonIds,
    maxDistance: radius,
    count: 10
  })

  log('SCAN', `Chest: ${chestBlocks.length}, Dispenser: ${dispenserBlocks.length}, Button: ${buttonBlocks.length}`)

  if (chestBlocks.length === 0 || dispenserBlocks.length === 0 || buttonBlocks.length < 2) {
    await msg.toOwner(bot, t('scanNotFound'))
    await msg.toOwner(bot, `❌ Chest:${chestBlocks.length} Disp:${dispenserBlocks.length} Btn:${buttonBlocks.length}`)
    return false
  }

  // نزدیک‌ترین چست و دیسپنسر
  const chestPos = chestBlocks.sort((a, b) =>
    bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b))[0]
  const dispenserPos = dispenserBlocks.sort((a, b) =>
    bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b))[0]

  // دکمه‌ها: نزدیک‌ترین دو تا
  const sortedButtons = buttonBlocks.sort((a, b) =>
    bot.entity.position.distanceTo(a) - bot.entity.position.distanceTo(b))
  const btn1 = sortedButtons[0]
  const btn2 = sortedButtons[1]

  // دکمه‌ای که نزدیک‌تر به دیسپنسر هست = دکمه فایربال
  const d1 = btn1.distanceTo(dispenserPos)
  const d2 = btn2.distanceTo(dispenserPos)

  let buttonFireball, buttonMinecart
  if (d1 < d2) {
    buttonFireball = btn1
    buttonMinecart = btn2
  } else {
    buttonFireball = btn2
    buttonMinecart = btn1
  }

  mapping = {
    chest: chestPos,
    dispenser: dispenserPos,
    buttonFireball: buttonFireball,
    buttonMinecart: buttonMinecart
  }

  // ذخیره در config
  config.set('shulkerFarm.chestPos', { x: chestPos.x, y: chestPos.y, z: chestPos.z })
  config.set('shulkerFarm.dispenserPos', { x: dispenserPos.x, y: dispenserPos.y, z: dispenserPos.z })
  config.set('shulkerFarm.buttonFireball', { x: buttonFireball.x, y: buttonFireball.y, z: buttonFireball.z })
  config.set('shulkerFarm.buttonMinecartChest', { x: buttonMinecart.x, y: buttonMinecart.y, z: buttonMinecart.z })
  config.set('shulkerFarm.mapped', true)

  scanned = true
  await msg.toOwner(bot, t('scanDone'))
  await msg.toOwner(bot, `🔵 Chest @ y=${chestPos.y}  Disp @ y=${dispenserPos.y}`)
  await msg.toOwner(bot, `🔴 Btn-Minecart @ y=${buttonMinecart.y}  Btn-Fireball @ y=${buttonFireball.y}`)
  log('SCAN', 'نقشه دستگاه ساخته شد.')
  return true
}

/*
 * کلیک روی یه بلاک با رفتار انسانی
 */
async function humanClickBlock(bot, blockPos) {
  const block = bot.blockAt(blockPos)
  if (!block) {
    log('FARM', `بلاک در ${blockPos} پیدا نشد`)
    return false
  }
  await smoothLookAt(bot, blockPos.offset(0.5, 0.5, 0.5))
  await humanClickDelay()
  try {
    await bot.activateBlock(block)
    return true
  } catch (e) {
    log('FARM', `خطای کلیک: ${e.message}`)
    return false
  }
}

/*
 * منتقل کردن همه شالکرها از اینونتوری به کانتینر باز شده
 */
async function moveShulkersToContainer(bot, container) {
  let moved = 0
  const shulkerItems = bot.inventory.items().filter(i => /shulker_box/.test(i.name))

  for (const it of shulkerItems) {
    try {
      await container.deposit(it.type, null, it.count)
      moved++
      await delay(randInt(150, 300))
    } catch (e) {
      log('FARM', `خطای انتقال شالکر: ${e.message}`)
    }
  }
  return moved
}

/*
 * پیدا کردن ماین‌کارت‌چست نزدیک دیسپنسر (بعد از فشار دادن دکمه 1)
 */
function findNearestMinecartChest(bot, nearPos, maxDist = 4) {
  const entities = Object.values(bot.entities).filter(e => {
    if (!e) return false
    // در نسخه‌های مختلف اسم فرق میکنه
    const name = e.name || e.mobType || ''
    return /chest_minecart|minecart_chest|chest.*minecart/i.test(name)
  })
  if (entities.length === 0) return null

  const sorted = entities
    .map(e => ({ e, d: e.position.distanceTo(nearPos) }))
    .filter(x => x.d < maxDist)
    .sort((a, b) => a.d - b.d)

  return sorted[0]?.e
}

/*
 * یک سیکل کامل
 */
async function runCycle(bot) {
  if (!mapping) return false

  // 0) اطمینان از این که ماین‌کارت‌چست توی اینونتوری بات نباشه (دراپشون کن)
  const droppedMc = await dropMinecartChests(bot)
  if (droppedMc > 0) log('FARM', `${droppedMc} ماین‌کارت‌چست از اینونتوری دراپ شد`)

  // 1) دکمه ماین‌کارت
  log('FARM', 'کلیک روی دکمه ماین‌کارت...')
  const ok1 = await humanClickBlock(bot, mapping.buttonMinecart)
  if (!ok1) return false
  await delay(randInt(800, 1200))

  // 2) پیدا کردن ماین‌کارت‌چست جدید نزدیک دیسپنسر
  const mcEntity = findNearestMinecartChest(bot, mapping.dispenser, 5)
  if (!mcEntity) {
    log('FARM', 'ماین‌کارت‌چست پیدا نشد بعد از فشار دکمه')
    // بازم ادامه بده - شاید دستگاه فرق داره
  } else {
    // چرخش و باز کردن ماین‌کارت‌چست
    await smoothLookAt(bot, mcEntity.position)
    await humanClickDelay()

    try {
      const container = await bot.openContainer(mcEntity)
      const shulkerCount = bot.inventory.items().filter(i => /shulker_box/.test(i.name)).length
      if (shulkerCount > 0) {
        await moveShulkersToContainer(bot, container)
      }
      await delay(400)
      container.close()
    } catch (e) {
      log('FARM', `خطای باز کردن ماین‌کارت: ${e.message}`)
    }
  }

  // 3) کلیک روی دکمه فایربال
  await delay(randInt(400, 700))
  log('FARM', 'کلیک روی دکمه فایربال...')
  const ok2 = await humanClickBlock(bot, mapping.buttonFireball)
  if (!ok2) return false

  // 4) صبر برای انفجار و افتادن شالکرها
  await delay(randInt(2500, 3500))

  cycleCount++
  await msg.toOwner(bot, t('farmCycleDone', cycleCount))
  return true
}

async function start(bot) {
  if (running) {
    await msg.toOwner(bot, '⚠ مود فارم از قبل فعاله.')
    return
  }
  running = true
  stopFlag = false
  cycleCount = 0

  if (!scanned) {
    const ok = await scanArea(bot)
    if (!ok) {
      running = false
      return
    }
  }

  await msg.toOwner(bot, t('farmStarted'))
  log('FARM', 'حلقه فارم شروع شد')

  while (!stopFlag && running) {
    try {
      await runCycle(bot)
      await delay(randInt(600, 1200))
    } catch (e) {
      log('FARM', `خطای سیکل: ${e.message}`)
      await delay(2000)
    }
  }

  running = false
  await msg.toOwner(bot, t('farmStopped'))
}

async function stop(bot) {
  stopFlag = true
  running = false
  await msg.toOwner(bot, t('farmStopped'))
}

async function status(bot) {
  await msg.toOwner(bot,
    `🏭 Farm: ${running ? 'ACTIVE' : 'STOPPED'} | Cycles: ${cycleCount} | Mapped: ${scanned}`
  )
}

async function rescan(bot) {
  scanned = false
  await scanArea(bot)
}

function isRunning() {
  return running
}

module.exports = { start, stop, status, rescan, scanArea, isRunning }
