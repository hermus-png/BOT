'use strict'

/*
 * ═══════════════════════════════════════════════════════════════════
 *   MODE 2: KIT DISTRIBUTION
 * ═══════════════════════════════════════════════════════════════════
 *
 * ?kit pvp → گرفتن شالکر گیر + توتم از چست → تیپی → دراپ → !confirm → /kill
 */

const { log } = require('../utils/logger')
const { t } = require('../utils/messages')
const msg = require('../utils/msg')
const config = require('../utils/config')
const chatQueue = require('../utils/chatQueue')
const { delay, smoothLookAt, humanClickDelay } = require('../utils/human')
const tpa = require('../commands/tpa')

let state = 'idle'
let gearItem = null
let totemItem = null

function inspectShulker(item) {
  try {
    if (!item.nbt) return { contents: [] }
    const nbt = item.nbt

    let items = []

    const bet = nbt.value?.BlockEntityTag?.value
    if (bet?.Items?.value?.value) {
      items = bet.Items.value.value.map(it => ({
        id: it.id?.value || '',
        count: it.Count?.value || 0
      }))
    }

    const components = nbt.value?.components?.value
    if (components?.['minecraft:container']?.value?.value) {
      items = components['minecraft:container'].value.value.map(entry => {
        const it = entry.item?.value || entry
        return {
          id: it.id?.value || '',
          count: it.count?.value || 1
        }
      })
    }

    return { contents: items }
  } catch (e) {
    log('KIT', `خطای NBT: ${e.message}`)
    return { contents: [] }
  }
}

function isGearShulker(shulker) {
  const info = inspectShulker(shulker)
  const ids = info.contents.map(i => i.id.replace('minecraft:', ''))
  const hasCrystal = ids.some(i => i.includes('end_crystal'))
  const hasNetheriteArmor = ids.some(i => i.startsWith('netherite_'))
  const hasSword = ids.some(i => i.includes('sword'))
  const hasGapple = ids.some(i => i.includes('golden_apple'))
  const score = [hasCrystal, hasNetheriteArmor, hasSword, hasGapple].filter(Boolean).length
  return score >= 3
}

function isTotemShulker(shulker) {
  const info = inspectShulker(shulker)
  const totemCount = info.contents.filter(i =>
    i.id.includes('totem_of_undying')).reduce((s, i) => s + (i.count || 1), 0)
  return totemCount >= 10
}

async function findShulkerInChest(bot, chestPos, predicate) {
  const block = bot.blockAt(chestPos)
  if (!block) return null

  await smoothLookAt(bot, chestPos.offset(0.5, 0.5, 0.5))
  await humanClickDelay()

  let container
  try {
    container = await bot.openContainer(block)
  } catch (e) {
    log('KIT', `خطای باز کردن چست: ${e.message}`)
    return null
  }

  await delay(500)

  const shulkers = container.containerItems().filter(i => /shulker_box/.test(i.name))
  let found = null
  for (const s of shulkers) {
    if (predicate(s)) {
      found = s
      break
    }
  }

  if (found) {
    try {
      await container.withdraw(found.type, null, 1)
      await delay(400)
    } catch (e) {
      log('KIT', `خطای برداشت شالکر: ${e.message}`)
      found = null
    }
  }

  container.close()
  return found
}

function findNearbyChests(bot, radius = 12) {
  const mcData = require('minecraft-data')(bot.version)
  return bot.findBlocks({
    matching: [mcData.blocksByName.chest.id],
    maxDistance: radius,
    count: 20
  })
}

async function fetchKit(bot) {
  state = 'fetching'
  log('KIT', 'شروع دریافت کیت')

  const chests = findNearbyChests(bot, 12)
  if (chests.length === 0) {
    await msg.toOwner(bot, '❌ چستی توی محدوده پیدا نشد.')
    state = 'idle'
    return false
  }

  gearItem = null
  totemItem = null

  for (const cp of chests) {
    if (!gearItem) {
      const found = await findShulkerInChest(bot, cp, isGearShulker)
      if (found) {
        gearItem = found
        log('KIT', 'شالکر گیر پیدا شد.')
      }
    }
    if (!totemItem) {
      const found = await findShulkerInChest(bot, cp, isTotemShulker)
      if (found) {
        totemItem = found
        log('KIT', 'شالکر توتم پیدا شد.')
      }
    }
    if (gearItem && totemItem) break
    await delay(300)
  }

  if (!gearItem) {
    await msg.toOwner(bot, t('kitNoGear'))
    state = 'idle'
    return false
  }
  if (!totemItem) {
    await msg.toOwner(bot, t('kitNoTotem'))
    state = 'idle'
    return false
  }

  return true
}

async function tpToOwner(bot) {
  state = 'tping'
  log('KIT', 'فرستادن /tpa به pvp_HS')
  await tpa.sendTpaToOwner(bot)
  await delay(6000)
}

async function verifyOwnerNearby(bot) {
  const ownerName = config.get('owner.name')
  const owner = Object.values(bot.entities).find(e =>
    e.type === 'player' && e.username === ownerName)
  if (!owner) return false
  const dist = bot.entity.position.distanceTo(owner.position)
  return dist < 8
}

async function dropKit(bot) {
  state = 'dropping'
  log('KIT', 'دراپ شالکرها')

  const shulkers = bot.inventory.items().filter(i => /shulker_box/.test(i.name))
  for (const s of shulkers) {
    try {
      await bot.tossStack(s)
      await humanClickDelay()
    } catch (e) {
      log('KIT', `خطای دراپ: ${e.message}`)
    }
  }

  await msg.toOwner(bot, t('kitReady'))
  state = 'waiting_confirm'
}

async function killSelf(bot) {
  if (state !== 'waiting_confirm') {
    await msg.toOwner(bot, '⚠ الان توی حالت انتظار تایید نیستم.')
    return
  }
  state = 'killed'
  log('KIT', '/kill زدن')
  await chatQueue.send(bot, '/kill')
  await delay(1500)
  await msg.toOwner(bot, t('kitDone'))
  state = 'idle'
}

async function runKit(bot) {
  if (state !== 'idle') {
    await msg.toOwner(bot, `⚠ الان توی حالت ${state} هستم.`)
    return
  }

  const ok = await fetchKit(bot)
  if (!ok) return

  await tpToOwner(bot)

  let attempts = 0
  while (attempts < 3 && !(await verifyOwnerNearby(bot))) {
    await delay(2000)
    attempts++
  }

  if (!(await verifyOwnerNearby(bot))) {
    await msg.toOwner(bot, '⚠ نتونستم بهت برسم. کیت رو همینجا دراپ میکنم.')
  }

  await dropKit(bot)
}

function getState() { return state }

module.exports = { runKit, killSelf, getState }
