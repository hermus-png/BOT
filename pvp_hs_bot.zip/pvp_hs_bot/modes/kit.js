'use strict'

/*
 * ═══════════════════════════════════════════════════════════════════
 *   MODE 2: KIT DISTRIBUTION
 * ═══════════════════════════════════════════════════════════════════
 *
 * وقتی مالک بزنه: ?kit pvp
 *
 * 1) بات میره سمت چست‌های ذخیره شده (که مالک تنظیم کرده)
 * 2) توی هر چست دنبال یک شالکر می‌گرده:
 *    - شالکر گیر: شامل Crystal, Armor Netherite, Golden Apple, Sword
 *    - شالکر توتم: پر از Totem of Undying
 * 3) هر دو شالکر رو برمیداره
 * 4) به pvp_HS تیپی می‌فرسته (!tpa داخلی)
 * 5) اسم مالک رو confirm میکنه (چک نزدیک بودن)
 * 6) شالکرها رو دراپ میکنه
 * 7) در /msg میگه: "کیت آماده"
 * 8) منتظر !confirm از مالک میمونه
 * 9) بعد از !confirm، /kill می‌زنه
 * 10) بعد از respawn، برای بار بعدی آماده‌ست
 *
 * تشخیص محتوای شالکر:
 * - وقتی روی زمین کلیک راست بشه بازش نمیکنه (چون فقط توی چست هست)
 * - از NBT tag استفاده میکنیم که ذخیره داره چی توش هست
 */

const { log } = require('../utils/logger')
const { t } = require('../utils/messages')
const msg = require('../utils/msg')
const config = require('../utils/config')
const chatQueue = require('../utils/chatQueue')
const { delay, smoothLookAt, humanClickDelay, randInt } = require('../utils/human')
const tpa = require('../commands/tpa')

let state = 'idle'  // idle | fetching | tping | dropping | waiting_confirm | killed
let gearItem = null
let totemItem = null

/*
 * تشخیص اینکه یه shulker_box حاوی چه آیتم‌هایی هست از روی NBT
 */
function inspectShulker(item) {
  try {
    if (!item.nbt) return { contents: [] }
    const nbt = item.nbt

    // ساختار NBT شالکر:
    // BlockEntityTag > Items > [{id, Count, Slot, tag}]
    // در نسخه 1.20.5+ آیتم‌ها ممکنه توی components باشن
    let items = []

    // روش قدیمی
    const bet = nbt.value?.BlockEntityTag?.value
    if (bet?.Items?.value?.value) {
      items = bet.Items.value.value.map(it => {
        return {
          id: it.id?.value || '',
          count: it.Count?.value || 0
        }
      })
    }

    // روش جدید (1.20.5+ با components)
    const components = nbt.value?.components?.value
    if (components?.['minecraft:container']?.value?.value) {
      items = components['minecraft:container'].value.value.map(entry => {
        const it = entry.item?.value || entry
        return {
          id: it.id?.value || '',
          count: it.count?.value || 1
        }
      })
    }

    return { contents: items }
  } catch (e) {
    log('KIT', `خطای NBT: ${e.message}`)
    return { contents: [] }
  }
}

function isGearShulker(shulker) {
  const info = inspectShulker(shulker)
  const ids = info.contents.map(i => i.id.replace('minecraft:', ''))
  let hasCrystal = ids.some(i => i.includes('end_crystal'))
  let hasNetheriteArmor = ids.some(i => i.startsWith('netherite_'))
  let hasSword = ids.some(i => i.includes('sword'))
  let hasGapple = ids.some(i => i.includes('golden_apple') || i.includes('enchanted_golden_apple'))

  // حداقل 3 تا از این 4 تا
  const score = [hasCrystal, hasNetheriteArmor, hasSword, hasGapple].filter(Boolean).length
  return score >= 3
}

function isTotemShulker(shulker) {
  const info = inspectShulker(shulker)
  const totemCount = info.contents.filter(i =>
    i.id.includes('totem_of_undying')).reduce((s, i) => s + (i.count || 1), 0)
  // اگه بیشتر از نصف اسلات‌ها توتم باشه
  return totemCount >= 10
}

/*
 * باز کردن یه چست و پیدا کردن شالکر مناسب
 */
async function findShulkerInChest(bot, chestPos, predicate) {
  const block = bot.blockAt(chestPos)
  if (!block) return null

  await smoothLookAt(bot, chestPos.offset(0.5, 0.5, 0.5))
  await humanClickDelay()

  let container
  try {
    container = await bot.openContainer(block)
  } catch (e) {
    log('KIT', `خطای باز کردن چست: ${e.message}`)
    return null
  }

  await delay(500)

  // پیدا کردن شالکر
  const shulkers = container.containerItems().filter(i => /shulker_box/.test(i.name))
  let found = null
  for (const s of shulkers) {
    if (predicate(s)) {
      found = s
      break
    }
  }

  if (found) {
    try {
      await container.withdraw(found.type, null, 1)
      await delay(400)
    } catch (e) {
      log('KIT', `خطای برداشت شالکر: ${e.message}`)
      found = null
    }
  }

  container.close()
  return found
}

/*
 * اسکن چست‌های اطراف
 */
function findNearbyChests(bot, radius = 12) {
  const mcData = require('minecraft-data')(bot.version)
  return bot.findBlocks({
    matching: [mcData.blocksByName.chest.id],
    maxDistance: radius,
    count: 20
  })
}

/*
 * فاز 1: پیدا کردن و برداشتن هر دو شالکر
 */
async function fetchKit(bot) {
  state = 'fetching'
  log('KIT', 'شروع دریافت کیت')

  const chests = findNearbyChests(bot, 12)
  if (chests.length === 0) {
    await msg.toOwner(bot, '❌ چستی توی محدوده پیدا نشد.')
    state = 'idle'
    return false
  }

  gearItem = null
  totemItem = null

  for (const cp of chests) {
    if (!gearItem) {
      const found = await findShulkerInChest(bot, cp, isGearShulker)
      if (found) {
        gearItem = found
        log('KIT', 'شالکر گیر پیدا شد.')
      }
    }
    if (!totemItem) {
      const found = await findShulkerInChest(bot, cp, isTotemShulker)
      if (found) {
        totemItem = found
        log('KIT', 'شالکر توتم پیدا شد.')
      }
    }
    if (gearItem && totemItem) break
    await delay(300)
  }

  if (!gearItem) {
    await msg.toOwner(bot, t('kitNoGear'))
    state = 'idle'
    return false
  }
  if (!totemItem) {
    await msg.toOwner(bot, t('kitNoTotem'))
    state = 'idle'
    return false
  }

  return true
}

/*
 * فاز 2: تیپی به مالک
 */
async function tpToOwner(bot) {
  state = 'tping'
  log('KIT', 'فرستادن /tpa به pvp_HS')
  await tpa.sendTpaToOwner(bot)
  // منتظر تلپورت شدن - سرور در حالت عادی 30 ثانیه صبر میکنه تا قبول بشه
  await delay(6000)
}

/*
 * فاز 3: تایید حضور مالک (چک نزدیک بودن)
 */
async function verifyOwnerNearby(bot) {
  const ownerName = config.get('owner.name')
  const owner = Object.values(bot.entities).find(e =>
    e.type === 'player' && e.username === ownerName)
  if (!owner) return false
  const dist = bot.entity.position.distanceTo(owner.position)
  return dist < 8
}

/*
 * فاز 4: دراپ شالکرها
 */
async function dropKit(bot) {
  state = 'dropping'
  log('KIT', 'دراپ شالکرها')

  const shulkers = bot.inventory.items().filter(i => /shulker_box/.test(i.name))
  for (const s of shulkers) {
    try {
      await bot.tossStack(s)
      await humanClickDelay()
    } catch (e) {
      log('KIT', `خطای دراپ: ${e.message}`)
    }
  }

  await msg.toOwner(bot, t('kitReady'))
  state = 'waiting_confirm'
}

/*
 * فاز 5: /kill بعد از !confirm
 */
async function killSelf(bot) {
  if (state !== 'waiting_confirm') {
    await msg.toOwner(bot, '⚠ الان توی حالت انتظار تایید نیستم.')
    return
  }
  state = 'killed'
  log('KIT', '/kill زدن')
  await chatQueue.send(bot, '/kill')
  await delay(1500)
  await msg.toOwner(bot, t('kitDone'))
  state = 'idle'
}

/*
 * ورودی اصلی: ?kit pvp
 */
async function runKit(bot) {
  if (state !== 'idle') {
    await msg.toOwner(bot, `⚠ الان توی حالت ${state} هستم.`)
    return
  }

  const ok = await fetchKit(bot)
  if (!ok) return

  await tpToOwner(bot)

  // چک اینکه مالک نزدیکه
  let attempts = 0
  while (attempts < 3 && !(await verifyOwnerNearby(bot))) {
    await delay(2000)
    attempts++
  }

  if (!(await verifyOwnerNearby(bot))) {
    await msg.toOwner(bot, '⚠ نتونستم بهت برسم. کیت رو همینجا دراپ میکنم.')
  }

  await dropKit(bot)
}

function getState() { return state }

module.exports = { runKit, killSelf, getState }
